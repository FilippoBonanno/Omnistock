<?php
			$optionsArray = array(
	'totals' => array(
		'sku' => array(
			'totalsType' => '' 
		),
		'id_prestashop' => array(
			'totalsType' => '' 
		),
		'title' => array(
			'totalsType' => '' 
		),
		'brand_id' => array(
			'totalsType' => '' 
		),
		'supplier_id' => array(
			'totalsType' => '' 
		),
		'ean' => array(
			'totalsType' => '' 
		),
		'mpn' => array(
			'totalsType' => '' 
		),
		'tax_class' => array(
			'totalsType' => '' 
		),
		'weight_kg' => array(
			'totalsType' => '' 
		),
		'price_cost' => array(
			'totalsType' => '' 
		),
		'desc_short' => array(
			'totalsType' => '' 
		),
		'desc_long' => array(
			'totalsType' => '' 
		),
		'min_stock' => array(
			'totalsType' => '' 
		),
		'default_category_id' => array(
			'totalsType' => '' 
		),
		'category_1' => array(
			'totalsType' => '' 
		),
		'category_2' => array(
			'totalsType' => '' 
		),
		'category_3' => array(
			'totalsType' => '' 
		),
		'category_4' => array(
			'totalsType' => '' 
		),
		'total_stock' => array(
			'totalsType' => '' 
		),
		'created_at' => array(
			'totalsType' => '' 
		),
		'updated_at' => array(
			'totalsType' => '' 
		),
		'cover_url' => array(
			'totalsType' => '' 
		),
		'price_internal' => array(
			'totalsType' => '' 
		),
		'master_sku' => array(
			'totalsType' => '' 
		) 
	),
	'fields' => array(
		'gridFields' => array( 
			'sku',
			'id_prestashop',
			'title',
			'brand_id',
			'supplier_id',
			'ean',
			'mpn',
			'tax_class',
			'weight_kg',
			'price_cost',
			'desc_short',
			'desc_long',
			'min_stock',
			'default_category_id',
			'category_1',
			'category_2',
			'category_3',
			'category_4',
			'total_stock',
			'created_at',
			'updated_at',
			'cover_url',
			'price_internal',
			'master_sku' 
		),
		'exportFields' => array( 
			'sku',
			'id_prestashop',
			'title',
			'brand_id',
			'supplier_id',
			'ean',
			'mpn',
			'tax_class',
			'weight_kg',
			'price_cost',
			'desc_short',
			'desc_long',
			'min_stock',
			'default_category_id',
			'category_1',
			'category_2',
			'category_3',
			'category_4',
			'total_stock',
			'created_at',
			'updated_at',
			'cover_url',
			'price_internal',
			'master_sku' 
		),
		'searchRequiredFields' => array( 
			 
		),
		'searchPanelFields' => array( 
			 
		),
		'fieldItems' => array(
			'sku' => array( 
				'export_field' 
			),
			'id_prestashop' => array( 
				'export_field1' 
			),
			'title' => array( 
				'export_field2' 
			),
			'brand_id' => array( 
				'export_field3' 
			),
			'supplier_id' => array( 
				'export_field4' 
			),
			'ean' => array( 
				'export_field5' 
			),
			'mpn' => array( 
				'export_field6' 
			),
			'tax_class' => array( 
				'export_field7' 
			),
			'weight_kg' => array( 
				'export_field8' 
			),
			'price_cost' => array( 
				'export_field9' 
			),
			'desc_short' => array( 
				'export_field10' 
			),
			'desc_long' => array( 
				'export_field11' 
			),
			'min_stock' => array( 
				'export_field12' 
			),
			'default_category_id' => array( 
				'export_field13' 
			),
			'category_1' => array( 
				'export_field14' 
			),
			'category_2' => array( 
				'export_field15' 
			),
			'category_3' => array( 
				'export_field16' 
			),
			'category_4' => array( 
				'export_field17' 
			),
			'total_stock' => array( 
				'export_field18' 
			),
			'created_at' => array( 
				'export_field19' 
			),
			'updated_at' => array( 
				'export_field20' 
			),
			'cover_url' => array( 
				'export_field21' 
			),
			'price_internal' => array( 
				'export_field22' 
			),
			'master_sku' => array( 
				'export_field23' 
			) 
		) 
	),
	'pageLinks' => array(
		'edit' => false,
		'add' => false,
		'view' => false,
		'print' => false 
	),
	'layoutHelper' => array(
		'formItems' => array(
			'formItems' => array(
				'supertop' => array( 
					 
				),
				'top' => array( 
					'export_header' 
				),
				'grid' => array( 
					'export_field',
					'export_field1',
					'export_field2',
					'export_field3',
					'export_field4',
					'export_field5',
					'export_field6',
					'export_field7',
					'export_field8',
					'export_field9',
					'export_field10',
					'export_field11',
					'export_field12',
					'export_field13',
					'export_field14',
					'export_field15',
					'export_field16',
					'export_field17',
					'export_field18',
					'export_field19',
					'export_field20',
					'export_field21',
					'export_field22',
					'export_field23' 
				),
				'footer' => array( 
					'export_export',
					'export_cancel' 
				) 
			),
			'formXtTags' => array(
				'supertop' => array( 
					 
				) 
			),
			'itemForms' => array(
				'export_header' => 'top',
				'export_field' => 'grid',
				'export_field1' => 'grid',
				'export_field2' => 'grid',
				'export_field3' => 'grid',
				'export_field4' => 'grid',
				'export_field5' => 'grid',
				'export_field6' => 'grid',
				'export_field7' => 'grid',
				'export_field8' => 'grid',
				'export_field9' => 'grid',
				'export_field10' => 'grid',
				'export_field11' => 'grid',
				'export_field12' => 'grid',
				'export_field13' => 'grid',
				'export_field14' => 'grid',
				'export_field15' => 'grid',
				'export_field16' => 'grid',
				'export_field17' => 'grid',
				'export_field18' => 'grid',
				'export_field19' => 'grid',
				'export_field20' => 'grid',
				'export_field21' => 'grid',
				'export_field22' => 'grid',
				'export_field23' => 'grid',
				'export_export' => 'footer',
				'export_cancel' => 'footer' 
			),
			'itemLocations' => array(
				 
			),
			'itemVisiblity' => array(
				 
			) 
		),
		'itemsByType' => array(
			'export_header' => array( 
				'export_header' 
			),
			'export_export' => array( 
				'export_export' 
			),
			'export_cancel' => array( 
				'export_cancel' 
			),
			'export_field' => array( 
				'export_field',
				'export_field1',
				'export_field2',
				'export_field3',
				'export_field4',
				'export_field5',
				'export_field6',
				'export_field7',
				'export_field8',
				'export_field9',
				'export_field10',
				'export_field11',
				'export_field12',
				'export_field13',
				'export_field14',
				'export_field15',
				'export_field16',
				'export_field17',
				'export_field18',
				'export_field19',
				'export_field20',
				'export_field21',
				'export_field22',
				'export_field23' 
			) 
		),
		'cellMaps' => array(
			 
		) 
	),
	'loginForm' => array(
		'loginForm' => 3 
	),
	'page' => array(
		'verticalBar' => false,
		'labeledButtons' => array(
			'update_records' => array(
				 
			),
			'print_pages' => array(
				 
			),
			'register_activate_message' => array(
				 
			),
			'details_found' => array(
				 
			) 
		),
		'hasCustomButtons' => false,
		'customButtons' => array( 
			 
		),
		'codeSnippets' => array( 
			 
		),
		'clickHandlerSnippets' => array( 
			 
		),
		'hasNotifications' => false,
		'menus' => array( 
			 
		),
		'calcTotalsFor' => 1,
		'hasCharts' => false 
	),
	'events' => array(
		'maps' => array( 
			 
		),
		'mapsData' => array(
			 
		),
		'buttons' => array( 
			 
		) 
	),
	'export' => array(
		'format' => 2,
		'selectFields' => false,
		'delimiter' => ',',
		'selectDelimiter' => false,
		'exportFileTypes' => array(
			'excel' => true,
			'word' => true,
			'csv' => true,
			'xml' => false 
		) 
	) 
);
			$pageArray = array(
	'id' => 'export',
	'type' => 'export',
	'layoutId' => 'first',
	'disabled' => false,
	'default' => 0,
	'forms' => array(
		'supertop' => array(
			'modelId' => 'panel-top',
			'grid' => array( 
				array(
					'cells' => array( 
						array(
							'cell' => 'c1' 
						) 
					),
					'section' => '' 
				) 
			),
			'cells' => array(
				'c1' => array(
					'model' => 'c1',
					'items' => array( 
						 
					) 
				) 
			),
			'deferredItems' => array( 
				 
			),
			'recsPerRow' => 1 
		),
		'top' => array(
			'modelId' => 'export-header',
			'grid' => array( 
				array(
					'cells' => array( 
						array(
							'cell' => 'c1' 
						) 
					),
					'section' => '' 
				) 
			),
			'cells' => array(
				'c1' => array(
					'model' => 'c1',
					'items' => array( 
						'export_header' 
					) 
				) 
			),
			'deferredItems' => array( 
				 
			),
			'recsPerRow' => 1 
		),
		'grid' => array(
			'modelId' => 'export-grid',
			'grid' => array( 
				array(
					'cells' => array( 
						array(
							'cell' => 'c1' 
						) 
					),
					'section' => '' 
				) 
			),
			'cells' => array(
				'c1' => array(
					'model' => 'c1',
					'items' => array( 
						'export_field',
						'export_field1',
						'export_field2',
						'export_field3',
						'export_field4',
						'export_field5',
						'export_field6',
						'export_field7',
						'export_field8',
						'export_field9',
						'export_field10',
						'export_field11',
						'export_field12',
						'export_field13',
						'export_field14',
						'export_field15',
						'export_field16',
						'export_field17',
						'export_field18',
						'export_field19',
						'export_field20',
						'export_field21',
						'export_field22',
						'export_field23' 
					) 
				) 
			),
			'deferredItems' => array( 
				 
			),
			'recsPerRow' => 1 
		),
		'footer' => array(
			'modelId' => 'export-footer',
			'grid' => array( 
				array(
					'cells' => array( 
						array(
							'cell' => 'c1' 
						),
						array(
							'cell' => 'c2' 
						) 
					),
					'section' => '' 
				) 
			),
			'cells' => array(
				'c1' => array(
					'model' => 'c1',
					'items' => array( 
						 
					) 
				),
				'c2' => array(
					'model' => 'c2',
					'items' => array( 
						'export_export',
						'export_cancel' 
					) 
				) 
			),
			'deferredItems' => array( 
				 
			),
			'recsPerRow' => 1 
		) 
	),
	'items' => array(
		'export_header' => array(
			'type' => 'export_header' 
		),
		'export_export' => array(
			'type' => 'export_export' 
		),
		'export_cancel' => array(
			'type' => 'export_cancel' 
		),
		'export_field' => array(
			'field' => 'sku',
			'type' => 'export_field' 
		),
		'export_field1' => array(
			'field' => 'id_prestashop',
			'type' => 'export_field' 
		),
		'export_field2' => array(
			'field' => 'title',
			'type' => 'export_field' 
		),
		'export_field3' => array(
			'field' => 'brand_id',
			'type' => 'export_field' 
		),
		'export_field4' => array(
			'field' => 'supplier_id',
			'type' => 'export_field' 
		),
		'export_field5' => array(
			'field' => 'ean',
			'type' => 'export_field' 
		),
		'export_field6' => array(
			'field' => 'mpn',
			'type' => 'export_field' 
		),
		'export_field7' => array(
			'field' => 'tax_class',
			'type' => 'export_field' 
		),
		'export_field8' => array(
			'field' => 'weight_kg',
			'type' => 'export_field' 
		),
		'export_field9' => array(
			'field' => 'price_cost',
			'type' => 'export_field' 
		),
		'export_field10' => array(
			'field' => 'desc_short',
			'type' => 'export_field' 
		),
		'export_field11' => array(
			'field' => 'desc_long',
			'type' => 'export_field' 
		),
		'export_field12' => array(
			'field' => 'min_stock',
			'type' => 'export_field' 
		),
		'export_field13' => array(
			'field' => 'default_category_id',
			'type' => 'export_field' 
		),
		'export_field14' => array(
			'field' => 'category_1',
			'type' => 'export_field' 
		),
		'export_field15' => array(
			'field' => 'category_2',
			'type' => 'export_field' 
		),
		'export_field16' => array(
			'field' => 'category_3',
			'type' => 'export_field' 
		),
		'export_field17' => array(
			'field' => 'category_4',
			'type' => 'export_field' 
		),
		'export_field18' => array(
			'field' => 'total_stock',
			'type' => 'export_field' 
		),
		'export_field19' => array(
			'field' => 'created_at',
			'type' => 'export_field' 
		),
		'export_field20' => array(
			'field' => 'updated_at',
			'type' => 'export_field' 
		),
		'export_field21' => array(
			'field' => 'cover_url',
			'type' => 'export_field' 
		),
		'export_field22' => array(
			'field' => 'price_internal',
			'type' => 'export_field' 
		),
		'export_field23' => array(
			'field' => 'master_sku',
			'type' => 'export_field' 
		) 
	),
	'version' => 13,
	'imageItem' => array(
		'type' => 'page_image' 
	),
	'imageBgColor' => '#f2f2f2',
	'controlsBgColor' => 'white',
	'imagePosition' => 'right',
	'listTotals' => 1,
	'title' => array(
		 
	),
	'exportFormat' => 2,
	'exportDelimiter' => ',',
	'exportSelectDelimiter' => false,
	'exportSelectFields' => false 
);
		?>