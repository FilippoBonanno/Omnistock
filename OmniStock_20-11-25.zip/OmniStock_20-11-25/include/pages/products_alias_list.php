<?php
			$optionsArray = array(
	'list' => array(
		'inlineAdd' => false,
		'detailsAdd' => true,
		'inlineEdit' => true,
		'reorderRows' => false,
		'addToBottom' => false,
		'delete' => true,
		'updateSelected' => false,
		'addInPopup' => false,
		'editInPopup' => false,
		'viewInPopup' => false,
		'clickSort' => true,
		'sortDropdown' => false,
		'showHideFields' => false,
		'reorderFields' => false,
		'fieldFilter' => false,
		'hideNumberOfRecords' => false 
	),
	'master' => array(
		'products' => array(
			'preview' => true 
		) 
	),
	'listSearch' => array(
		'alwaysOnPanelFields' => array( 
			 
		),
		'searchPanel' => true,
		'fixedSearchPanel' => false,
		'simpleSearchOptions' => false,
		'searchSaving' => false 
	),
	'totals' => array(
		'sku' => array(
			'totalsType' => '' 
		),
		'id_prestashop' => array(
			'totalsType' => '' 
		),
		'title' => array(
			'totalsType' => '' 
		),
		'brand_id' => array(
			'totalsType' => '' 
		),
		'supplier_id' => array(
			'totalsType' => '' 
		),
		'ean' => array(
			'totalsType' => '' 
		),
		'mpn' => array(
			'totalsType' => '' 
		),
		'tax_class' => array(
			'totalsType' => '' 
		),
		'weight_kg' => array(
			'totalsType' => '' 
		),
		'price_cost' => array(
			'totalsType' => '' 
		),
		'desc_short' => array(
			'totalsType' => '' 
		),
		'desc_long' => array(
			'totalsType' => '' 
		),
		'min_stock' => array(
			'totalsType' => '' 
		),
		'default_category_id' => array(
			'totalsType' => '' 
		),
		'category_1' => array(
			'totalsType' => '' 
		),
		'category_2' => array(
			'totalsType' => '' 
		),
		'category_3' => array(
			'totalsType' => '' 
		),
		'category_4' => array(
			'totalsType' => '' 
		),
		'total_stock' => array(
			'totalsType' => '' 
		),
		'created_at' => array(
			'totalsType' => '' 
		),
		'updated_at' => array(
			'totalsType' => '' 
		),
		'cover_url' => array(
			'totalsType' => '' 
		),
		'price_internal' => array(
			'totalsType' => '' 
		),
		'master_sku' => array(
			'totalsType' => '' 
		) 
	),
	'fields' => array(
		'gridFields' => array( 
			'cover_url',
			'sku',
			'title',
			'brand_id',
			'supplier_id',
			'ean',
			'price_cost',
			'price_internal',
			'total_stock',
			'created_at' 
		),
		'searchRequiredFields' => array( 
			 
		),
		'searchPanelFields' => array( 
			'sku',
			'master_sku',
			'price_internal',
			'cover_url',
			'updated_at',
			'created_at',
			'total_stock',
			'category_4',
			'category_3',
			'category_2',
			'category_1',
			'default_category_id',
			'min_stock',
			'desc_long',
			'desc_short',
			'price_cost',
			'weight_kg',
			'tax_class',
			'mpn',
			'ean',
			'supplier_id',
			'brand_id',
			'title',
			'id_prestashop' 
		),
		'filterFields' => array( 
			'cover_url' 
		),
		'inlineAddFields' => array( 
			 
		),
		'inlineEditFields' => array( 
			'title',
			'brand_id',
			'supplier_id',
			'ean',
			'price_cost',
			'total_stock',
			'created_at',
			'price_internal' 
		),
		'fieldItems' => array(
			'sku' => array( 
				'simple_grid_field',
				'simple_grid_field22' 
			),
			'title' => array( 
				'simple_grid_field2',
				'simple_grid_field24' 
			),
			'brand_id' => array( 
				'simple_grid_field3',
				'simple_grid_field25' 
			),
			'supplier_id' => array( 
				'simple_grid_field4',
				'simple_grid_field26' 
			),
			'ean' => array( 
				'simple_grid_field5',
				'simple_grid_field27' 
			),
			'price_cost' => array( 
				'simple_grid_field9',
				'simple_grid_field31' 
			),
			'total_stock' => array( 
				'simple_grid_field18',
				'simple_grid_field40' 
			),
			'created_at' => array( 
				'simple_grid_field19',
				'simple_grid_field41' 
			),
			'cover_url' => array( 
				'simple_grid_field21',
				'simple_grid_field43' 
			),
			'price_internal' => array( 
				'grid_field',
				'grid_field_label' 
			) 
		),
		'hideEmptyFields' => array( 
			 
		),
		'fieldFilterFields' => array( 
			 
		) 
	),
	'pageLinks' => array(
		'edit' => true,
		'add' => true,
		'view' => true,
		'print' => true 
	),
	'layoutHelper' => array(
		'formItems' => array(
			'formItems' => array(
				'above-grid' => array( 
					'add',
					'inline_add',
					'inline_save_all',
					'inline_cancel_all',
					'delete',
					'text4',
					'details_found',
					'page_size',
					'print_panel' 
				),
				'below-grid' => array( 
					'pagination' 
				),
				'left' => array( 
					'logo',
					'expand_button',
					'menu',
					'search_panel',
					'filter_panel' 
				),
				'supertop' => array( 
					'expand_menu_button',
					'collapse_button',
					'breadcrumb',
					'simple_search',
					'list_options',
					'loginform_login',
					'username_button' 
				),
				'top' => array( 
					'master_info' 
				),
				'grid' => array( 
					'simple_grid_field43',
					'simple_grid_field21',
					'simple_grid_field22',
					'text3',
					'simple_grid_field24',
					'simple_grid_field',
					'simple_grid_field2',
					'simple_grid_field25',
					'simple_grid_field3',
					'simple_grid_field26',
					'simple_grid_field4',
					'simple_grid_field27',
					'text2',
					'simple_grid_field31',
					'text1',
					'grid_field_label',
					'simple_grid_field5',
					'simple_grid_field9',
					'text',
					'grid_field',
					'simple_grid_field40',
					'simple_grid_field18',
					'grid_checkbox_head',
					'grid_checkbox',
					'grid_edit',
					'grid_inline_edit',
					'grid_view',
					'grid_inline_cancel',
					'grid_inline_save',
					'grid_delete',
					'grid_alldetails_link',
					'simple_grid_field41',
					'simple_grid_field19' 
				) 
			),
			'formXtTags' => array(
				'below-grid' => array( 
					'pagination' 
				),
				'top' => array( 
					'mastertable_block' 
				) 
			),
			'itemForms' => array(
				'add' => 'above-grid',
				'inline_add' => 'above-grid',
				'inline_save_all' => 'above-grid',
				'inline_cancel_all' => 'above-grid',
				'delete' => 'above-grid',
				'text4' => 'above-grid',
				'details_found' => 'above-grid',
				'page_size' => 'above-grid',
				'print_panel' => 'above-grid',
				'pagination' => 'below-grid',
				'logo' => 'left',
				'expand_button' => 'left',
				'menu' => 'left',
				'search_panel' => 'left',
				'filter_panel' => 'left',
				'expand_menu_button' => 'supertop',
				'collapse_button' => 'supertop',
				'breadcrumb' => 'supertop',
				'simple_search' => 'supertop',
				'list_options' => 'supertop',
				'loginform_login' => 'supertop',
				'username_button' => 'supertop',
				'master_info' => 'top',
				'simple_grid_field43' => 'grid',
				'simple_grid_field21' => 'grid',
				'simple_grid_field22' => 'grid',
				'text3' => 'grid',
				'simple_grid_field24' => 'grid',
				'simple_grid_field' => 'grid',
				'simple_grid_field2' => 'grid',
				'simple_grid_field25' => 'grid',
				'simple_grid_field3' => 'grid',
				'simple_grid_field26' => 'grid',
				'simple_grid_field4' => 'grid',
				'simple_grid_field27' => 'grid',
				'text2' => 'grid',
				'simple_grid_field31' => 'grid',
				'text1' => 'grid',
				'grid_field_label' => 'grid',
				'simple_grid_field5' => 'grid',
				'simple_grid_field9' => 'grid',
				'text' => 'grid',
				'grid_field' => 'grid',
				'simple_grid_field40' => 'grid',
				'simple_grid_field18' => 'grid',
				'grid_checkbox_head' => 'grid',
				'grid_checkbox' => 'grid',
				'grid_edit' => 'grid',
				'grid_inline_edit' => 'grid',
				'grid_view' => 'grid',
				'grid_inline_cancel' => 'grid',
				'grid_inline_save' => 'grid',
				'grid_delete' => 'grid',
				'grid_alldetails_link' => 'grid',
				'simple_grid_field41' => 'grid',
				'simple_grid_field19' => 'grid' 
			),
			'itemLocations' => array(
				'simple_grid_field43' => array(
					'location' => 'grid',
					'cellId' => 'headcell_field1' 
				),
				'simple_grid_field21' => array(
					'location' => 'grid',
					'cellId' => 'cell_field1' 
				),
				'simple_grid_field22' => array(
					'location' => 'grid',
					'cellId' => 'headcell_field2' 
				),
				'text3' => array(
					'location' => 'grid',
					'cellId' => 'headcell_field2' 
				),
				'simple_grid_field24' => array(
					'location' => 'grid',
					'cellId' => 'headcell_field2' 
				),
				'simple_grid_field' => array(
					'location' => 'grid',
					'cellId' => 'cell_field2' 
				),
				'simple_grid_field2' => array(
					'location' => 'grid',
					'cellId' => 'cell_field2' 
				),
				'simple_grid_field25' => array(
					'location' => 'grid',
					'cellId' => 'headcell_field3' 
				),
				'simple_grid_field3' => array(
					'location' => 'grid',
					'cellId' => 'cell_field3' 
				),
				'simple_grid_field26' => array(
					'location' => 'grid',
					'cellId' => 'headcell_field4' 
				),
				'simple_grid_field4' => array(
					'location' => 'grid',
					'cellId' => 'cell_field4' 
				),
				'simple_grid_field27' => array(
					'location' => 'grid',
					'cellId' => 'headcell_field5' 
				),
				'text2' => array(
					'location' => 'grid',
					'cellId' => 'headcell_field5' 
				),
				'simple_grid_field31' => array(
					'location' => 'grid',
					'cellId' => 'headcell_field5' 
				),
				'text1' => array(
					'location' => 'grid',
					'cellId' => 'headcell_field5' 
				),
				'grid_field_label' => array(
					'location' => 'grid',
					'cellId' => 'headcell_field5' 
				),
				'simple_grid_field5' => array(
					'location' => 'grid',
					'cellId' => 'cell_field5' 
				),
				'simple_grid_field9' => array(
					'location' => 'grid',
					'cellId' => 'cell_field5' 
				),
				'text' => array(
					'location' => 'grid',
					'cellId' => 'cell_field5' 
				),
				'grid_field' => array(
					'location' => 'grid',
					'cellId' => 'cell_field5' 
				),
				'simple_grid_field40' => array(
					'location' => 'grid',
					'cellId' => 'headcell_field18' 
				),
				'simple_grid_field18' => array(
					'location' => 'grid',
					'cellId' => 'cell_field18' 
				),
				'grid_checkbox_head' => array(
					'location' => 'grid',
					'cellId' => 'headcell_checkbox' 
				),
				'grid_checkbox' => array(
					'location' => 'grid',
					'cellId' => 'cell_checkbox' 
				),
				'grid_edit' => array(
					'location' => 'grid',
					'cellId' => 'cell_icons' 
				),
				'grid_inline_edit' => array(
					'location' => 'grid',
					'cellId' => 'cell_icons' 
				),
				'grid_view' => array(
					'location' => 'grid',
					'cellId' => 'cell_icons' 
				),
				'grid_inline_cancel' => array(
					'location' => 'grid',
					'cellId' => 'cell_icons' 
				),
				'grid_inline_save' => array(
					'location' => 'grid',
					'cellId' => 'cell_icons' 
				),
				'grid_delete' => array(
					'location' => 'grid',
					'cellId' => 'cell_icons' 
				),
				'grid_alldetails_link' => array(
					'location' => 'grid',
					'cellId' => 'cell_details' 
				),
				'simple_grid_field41' => array(
					'location' => 'grid',
					'cellId' => 'headcell_field6' 
				),
				'simple_grid_field19' => array(
					'location' => 'grid',
					'cellId' => 'cell_field6' 
				) 
			),
			'itemVisiblity' => array(
				'breadcrumb' => 5,
				'expand_menu_button' => 2,
				'print_panel' => 5,
				'expand_button' => 5 
			) 
		),
		'itemsByType' => array(
			'page_size' => array( 
				'page_size' 
			),
			'breadcrumb' => array( 
				'breadcrumb' 
			),
			'logo' => array( 
				'logo' 
			),
			'menu' => array( 
				'menu' 
			),
			'simple_search' => array( 
				'simple_search' 
			),
			'pagination' => array( 
				'pagination' 
			),
			'details_found' => array( 
				'details_found' 
			),
			'search_panel' => array( 
				'search_panel' 
			),
			'list_options' => array( 
				'list_options' 
			),
			'show_search_panel' => array( 
				'show_search_panel' 
			),
			'hide_search_panel' => array( 
				'hide_search_panel' 
			),
			'search_panel_field' => array( 
				'search_panel_field',
				'search_panel_field1',
				'search_panel_field2',
				'search_panel_field3',
				'search_panel_field4',
				'search_panel_field5',
				'search_panel_field6',
				'search_panel_field7',
				'search_panel_field8',
				'search_panel_field9',
				'search_panel_field10',
				'search_panel_field11',
				'search_panel_field12',
				'search_panel_field13',
				'search_panel_field14',
				'search_panel_field15',
				'search_panel_field16',
				'search_panel_field17',
				'search_panel_field18',
				'search_panel_field19',
				'search_panel_field20',
				'search_panel_field21',
				'search_panel_field22',
				'search_panel_field23' 
			),
			'username_button' => array( 
				'username_button' 
			),
			'loginform_login' => array( 
				'loginform_login' 
			),
			'userinfo_link' => array( 
				'userinfo_link' 
			),
			'logout_link' => array( 
				'logout_link' 
			),
			'expand_menu_button' => array( 
				'expand_menu_button' 
			),
			'collapse_button' => array( 
				'collapse_button' 
			),
			'add' => array( 
				'add' 
			),
			'export' => array( 
				'export' 
			),
			'-' => array( 
				'-',
				'-1',
				'-2',
				'-3' 
			),
			'export_selected' => array( 
				'export_selected' 
			),
			'import' => array( 
				'import' 
			),
			'print_panel' => array( 
				'print_panel' 
			),
			'print_scope' => array( 
				'print_scope' 
			),
			'print_button' => array( 
				'print_button' 
			),
			'print_records' => array( 
				'print_records' 
			),
			'delete' => array( 
				'delete',
				'grid_delete' 
			),
			'delete_selected' => array( 
				'delete_selected' 
			),
			'master_info' => array( 
				'master_info' 
			),
			'print_details' => array( 
				'print_details' 
			),
			'grid_field' => array( 
				'simple_grid_field',
				'simple_grid_field2',
				'simple_grid_field3',
				'simple_grid_field4',
				'simple_grid_field5',
				'simple_grid_field9',
				'simple_grid_field18',
				'simple_grid_field19',
				'simple_grid_field21',
				'grid_field' 
			),
			'grid_field_label' => array( 
				'simple_grid_field22',
				'simple_grid_field24',
				'simple_grid_field25',
				'simple_grid_field26',
				'simple_grid_field27',
				'simple_grid_field31',
				'simple_grid_field40',
				'simple_grid_field41',
				'simple_grid_field43',
				'grid_field_label' 
			),
			'grid_checkbox' => array( 
				'grid_checkbox' 
			),
			'grid_checkbox_head' => array( 
				'grid_checkbox_head' 
			),
			'grid_edit' => array( 
				'grid_edit' 
			),
			'grid_view' => array( 
				'grid_view' 
			),
			'grid_alldetails_link' => array( 
				'grid_alldetails_link' 
			),
			'filter_panel' => array( 
				'filter_panel' 
			),
			'filter_panel_field' => array( 
				'filter_panel_field' 
			),
			'grid_inline_cancel' => array( 
				'grid_inline_cancel' 
			),
			'grid_inline_save' => array( 
				'grid_inline_save' 
			),
			'edit_selected' => array( 
				'edit_selected' 
			),
			'grid_inline_edit' => array( 
				'grid_inline_edit' 
			),
			'inline_save_all' => array( 
				'inline_save_all' 
			),
			'inline_cancel_all' => array( 
				'inline_cancel_all' 
			),
			'text' => array( 
				'text',
				'text1',
				'text2',
				'text3',
				'text4' 
			),
			'expand_button' => array( 
				'expand_button' 
			),
			'inline_add' => array( 
				'inline_add' 
			) 
		),
		'cellMaps' => array(
			'grid' => array(
				'cells' => array(
					'headcell_icons' => array(
						'cols' => array( 
							0 
						),
						'rows' => array( 
							0 
						),
						'tags' => array( 
							 
						),
						'items' => array( 
							 
						),
						'fixedAtServer' => false,
						'fixedAtClient' => false 
					),
					'headcell_checkbox' => array(
						'cols' => array( 
							1 
						),
						'rows' => array( 
							0 
						),
						'tags' => array( 
							'checkbox_column' 
						),
						'items' => array( 
							'grid_checkbox_head' 
						),
						'fixedAtServer' => false,
						'fixedAtClient' => false 
					),
					'headcell_details' => array(
						'cols' => array( 
							2 
						),
						'rows' => array( 
							0 
						),
						'tags' => array( 
							 
						),
						'items' => array( 
							 
						),
						'fixedAtServer' => false,
						'fixedAtClient' => false 
					),
					'headcell_field1' => array(
						'cols' => array( 
							3 
						),
						'rows' => array( 
							0 
						),
						'tags' => array( 
							'cover_url_fieldheadercolumn' 
						),
						'items' => array( 
							'simple_grid_field43' 
						),
						'fixedAtServer' => false,
						'fixedAtClient' => false 
					),
					'headcell_field2' => array(
						'cols' => array( 
							4 
						),
						'rows' => array( 
							0 
						),
						'tags' => array( 
							 
						),
						'items' => array( 
							'simple_grid_field22',
							'text3',
							'simple_grid_field24' 
						),
						'fixedAtServer' => true,
						'fixedAtClient' => false 
					),
					'headcell_field3' => array(
						'cols' => array( 
							5 
						),
						'rows' => array( 
							0 
						),
						'tags' => array( 
							'brand_id_fieldheadercolumn' 
						),
						'items' => array( 
							'simple_grid_field25' 
						),
						'fixedAtServer' => false,
						'fixedAtClient' => false 
					),
					'headcell_field4' => array(
						'cols' => array( 
							6 
						),
						'rows' => array( 
							0 
						),
						'tags' => array( 
							'supplier_id_fieldheadercolumn' 
						),
						'items' => array( 
							'simple_grid_field26' 
						),
						'fixedAtServer' => false,
						'fixedAtClient' => false 
					),
					'headcell_field5' => array(
						'cols' => array( 
							7 
						),
						'rows' => array( 
							0 
						),
						'tags' => array( 
							 
						),
						'items' => array( 
							'simple_grid_field27',
							'text2',
							'simple_grid_field31',
							'text1',
							'grid_field_label' 
						),
						'fixedAtServer' => true,
						'fixedAtClient' => false 
					),
					'headcell_field18' => array(
						'cols' => array( 
							8 
						),
						'rows' => array( 
							0 
						),
						'tags' => array( 
							'total_stock_fieldheadercolumn' 
						),
						'items' => array( 
							'simple_grid_field40' 
						),
						'fixedAtServer' => false,
						'fixedAtClient' => false 
					),
					'headcell_field6' => array(
						'cols' => array( 
							9 
						),
						'rows' => array( 
							0 
						),
						'tags' => array( 
							'created_at_fieldheadercolumn' 
						),
						'items' => array( 
							'simple_grid_field41' 
						),
						'fixedAtServer' => false,
						'fixedAtClient' => false 
					),
					'cell_icons' => array(
						'cols' => array( 
							0 
						),
						'rows' => array( 
							1 
						),
						'tags' => array( 
							'edit_column',
							'inlineedit_column',
							'view_column',
							'inline_cancel',
							'inline_save',
							'deleteselected_link' 
						),
						'items' => array( 
							'grid_edit',
							'grid_inline_edit',
							'grid_view',
							'grid_inline_cancel',
							'grid_inline_save',
							'grid_delete' 
						),
						'fixedAtServer' => false,
						'fixedAtClient' => false 
					),
					'cell_checkbox' => array(
						'cols' => array( 
							1 
						),
						'rows' => array( 
							1 
						),
						'tags' => array( 
							'checkbox_column' 
						),
						'items' => array( 
							'grid_checkbox' 
						),
						'fixedAtServer' => false,
						'fixedAtClient' => false 
					),
					'cell_details' => array(
						'cols' => array( 
							2 
						),
						'rows' => array( 
							1 
						),
						'tags' => array( 
							 
						),
						'items' => array( 
							'grid_alldetails_link' 
						),
						'fixedAtServer' => true,
						'fixedAtClient' => false 
					),
					'cell_field1' => array(
						'cols' => array( 
							3 
						),
						'rows' => array( 
							1 
						),
						'tags' => array( 
							'cover_url_fieldcolumn' 
						),
						'items' => array( 
							'simple_grid_field21' 
						),
						'fixedAtServer' => false,
						'fixedAtClient' => false 
					),
					'cell_field2' => array(
						'cols' => array( 
							4 
						),
						'rows' => array( 
							1 
						),
						'tags' => array( 
							'sku_fieldcolumn',
							'title_fieldcolumn' 
						),
						'items' => array( 
							'simple_grid_field',
							'simple_grid_field2' 
						),
						'fixedAtServer' => false,
						'fixedAtClient' => false 
					),
					'cell_field3' => array(
						'cols' => array( 
							5 
						),
						'rows' => array( 
							1 
						),
						'tags' => array( 
							'brand_id_fieldcolumn' 
						),
						'items' => array( 
							'simple_grid_field3' 
						),
						'fixedAtServer' => false,
						'fixedAtClient' => false 
					),
					'cell_field4' => array(
						'cols' => array( 
							6 
						),
						'rows' => array( 
							1 
						),
						'tags' => array( 
							'supplier_id_fieldcolumn' 
						),
						'items' => array( 
							'simple_grid_field4' 
						),
						'fixedAtServer' => false,
						'fixedAtClient' => false 
					),
					'cell_field5' => array(
						'cols' => array( 
							7 
						),
						'rows' => array( 
							1 
						),
						'tags' => array( 
							 
						),
						'items' => array( 
							'simple_grid_field5',
							'simple_grid_field9',
							'text',
							'grid_field' 
						),
						'fixedAtServer' => true,
						'fixedAtClient' => false 
					),
					'cell_field18' => array(
						'cols' => array( 
							8 
						),
						'rows' => array( 
							1 
						),
						'tags' => array( 
							'total_stock_fieldcolumn' 
						),
						'items' => array( 
							'simple_grid_field18' 
						),
						'fixedAtServer' => false,
						'fixedAtClient' => false 
					),
					'cell_field6' => array(
						'cols' => array( 
							9 
						),
						'rows' => array( 
							1 
						),
						'tags' => array( 
							'created_at_fieldcolumn' 
						),
						'items' => array( 
							'simple_grid_field19' 
						),
						'fixedAtServer' => false,
						'fixedAtClient' => false 
					),
					'cell_dpreview' => array(
						'cols' => array( 
							0,
							1,
							2,
							3,
							4,
							5,
							6,
							7,
							8,
							9 
						),
						'rows' => array( 
							2 
						),
						'tags' => array( 
							 
						),
						'items' => array( 
							 
						),
						'fixedAtServer' => false,
						'fixedAtClient' => false 
					),
					'footcell_field6' => array(
						'cols' => array( 
							0,
							1,
							2,
							3,
							4,
							5,
							6,
							7,
							8,
							9 
						),
						'rows' => array( 
							3 
						),
						'tags' => array( 
							 
						),
						'items' => array( 
							 
						),
						'fixedAtServer' => false,
						'fixedAtClient' => false 
					) 
				),
				'width' => 10,
				'height' => 4 
			) 
		) 
	),
	'loginForm' => array(
		'loginForm' => 0 
	),
	'page' => array(
		'verticalBar' => true,
		'labeledButtons' => array(
			'update_records' => array(
				 
			),
			'print_pages' => array(
				 
			),
			'register_activate_message' => array(
				 
			),
			'details_found' => array(
				'details_found' => array(
					'tag' => 'DISPLAYING',
					'type' => 2 
				) 
			) 
		),
		'gridType' => 0,
		'recsPerRow' => 1,
		'hasCustomButtons' => false,
		'customButtons' => array( 
			 
		),
		'codeSnippets' => array( 
			 
		),
		'clickHandlerSnippets' => array( 
			 
		),
		'hasNotifications' => false,
		'menus' => array( 
			array(
				'id' => 'main',
				'horizontal' => false 
			) 
		),
		'calcTotalsFor' => 1,
		'hasCharts' => false 
	),
	'misc' => array(
		'type' => 'list',
		'breadcrumb' => true 
	),
	'events' => array(
		'maps' => array( 
			 
		),
		'mapsData' => array(
			 
		),
		'buttons' => array( 
			 
		) 
	),
	'dataGrid' => array(
		'groupFields' => array( 
			 
		) 
	) 
);
			$pageArray = array(
	'id' => 'list',
	'type' => 'list',
	'layoutId' => 'leftbar',
	'disabled' => false,
	'default' => 0,
	'forms' => array(
		'above-grid' => array(
			'modelId' => 'list-above-grid',
			'grid' => array( 
				array(
					'cells' => array( 
						array(
							'cell' => 'c1' 
						),
						array(
							'cell' => 'c2' 
						) 
					),
					'section' => '' 
				),
				array(
					'cells' => array( 
						array(
							'cell' => 'c3' 
						),
						array(
							'cell' => 'c4' 
						) 
					),
					'section' => '' 
				) 
			),
			'cells' => array(
				'c1' => array(
					'model' => 'c1',
					'items' => array( 
						'add',
						'inline_add',
						'inline_save_all',
						'inline_cancel_all',
						'delete',
						'text4' 
					) 
				),
				'c2' => array(
					'model' => 'c2',
					'items' => array( 
						'details_found',
						'page_size',
						'print_panel' 
					) 
				),
				'c3' => array(
					'model' => 'c3',
					'items' => array( 
						 
					) 
				),
				'c4' => array(
					'model' => 'c4',
					'items' => array( 
						 
					) 
				) 
			),
			'deferredItems' => array( 
				 
			),
			'recsPerRow' => 1 
		),
		'below-grid' => array(
			'modelId' => 'list-below-grid',
			'grid' => array( 
				array(
					'cells' => array( 
						array(
							'cell' => 'c1' 
						) 
					),
					'section' => '' 
				) 
			),
			'cells' => array(
				'c1' => array(
					'model' => 'c1',
					'items' => array( 
						'pagination' 
					) 
				) 
			),
			'deferredItems' => array( 
				 
			),
			'recsPerRow' => 1 
		),
		'left' => array(
			'modelId' => 'leftbar-menu',
			'grid' => array( 
				array(
					'cells' => array( 
						array(
							'cell' => 'c0' 
						) 
					),
					'section' => '' 
				),
				array(
					'cells' => array( 
						array(
							'cell' => 'c1' 
						) 
					),
					'section' => '' 
				) 
			),
			'cells' => array(
				'c0' => array(
					'model' => 'c0',
					'items' => array( 
						'logo',
						'expand_button' 
					) 
				),
				'c1' => array(
					'model' => 'c1',
					'items' => array( 
						'menu',
						'search_panel',
						'filter_panel' 
					) 
				) 
			),
			'deferredItems' => array( 
				 
			),
			'recsPerRow' => 1 
		),
		'supertop' => array(
			'modelId' => 'leftbar-top',
			'grid' => array( 
				array(
					'cells' => array( 
						array(
							'cell' => 'c1' 
						),
						array(
							'cell' => 'c2' 
						) 
					),
					'section' => '' 
				) 
			),
			'cells' => array(
				'c1' => array(
					'model' => 'c1',
					'items' => array( 
						'expand_menu_button',
						'collapse_button',
						'breadcrumb' 
					) 
				),
				'c2' => array(
					'model' => 'c2',
					'items' => array( 
						'simple_search',
						'list_options',
						'loginform_login',
						'username_button' 
					) 
				) 
			),
			'deferredItems' => array( 
				 
			),
			'recsPerRow' => 1 
		),
		'top' => array(
			'modelId' => 'list-sidebar-top',
			'grid' => array( 
				array(
					'cells' => array( 
						array(
							'cell' => 'c2' 
						) 
					),
					'section' => '' 
				) 
			),
			'cells' => array(
				'c2' => array(
					'model' => 'c2',
					'items' => array( 
						'master_info' 
					) 
				) 
			),
			'deferredItems' => array( 
				 
			),
			'recsPerRow' => 1 
		),
		'grid' => array(
			'modelId' => 'horizontal-grid',
			'grid' => array( 
				array(
					'section' => 'head',
					'cells' => array( 
						array(
							'cell' => 'headcell_icons' 
						),
						array(
							'cell' => 'headcell_checkbox' 
						),
						array(
							'cell' => 'headcell_details' 
						),
						array(
							'cell' => 'headcell_field1' 
						),
						array(
							'cell' => 'headcell_field2' 
						),
						array(
							'cell' => 'headcell_field3' 
						),
						array(
							'cell' => 'headcell_field4' 
						),
						array(
							'cell' => 'headcell_field5' 
						),
						array(
							'cell' => 'headcell_field18' 
						),
						array(
							'cell' => 'headcell_field6',
							'colspan' => 1 
						) 
					) 
				),
				array(
					'section' => 'body',
					'cells' => array( 
						array(
							'cell' => 'cell_icons' 
						),
						array(
							'cell' => 'cell_checkbox' 
						),
						array(
							'cell' => 'cell_details' 
						),
						array(
							'cell' => 'cell_field1' 
						),
						array(
							'cell' => 'cell_field2' 
						),
						array(
							'cell' => 'cell_field3' 
						),
						array(
							'cell' => 'cell_field4' 
						),
						array(
							'cell' => 'cell_field5' 
						),
						array(
							'cell' => 'cell_field18' 
						),
						array(
							'cell' => 'cell_field6',
							'colspan' => 1 
						) 
					) 
				),
				array(
					'cells' => array( 
						array(
							'cell' => 'cell_dpreview',
							'colspan' => 10 
						) 
					),
					'section' => 'body' 
				),
				array(
					'section' => 'foot',
					'cells' => array( 
						array(
							'cell' => 'footcell_field6',
							'colspan' => 10 
						) 
					) 
				) 
			),
			'cells' => array(
				'headcell_field1' => array(
					'model' => 'headcell_field',
					'items' => array( 
						'simple_grid_field43' 
					),
					'persistent' => false,
					'field' => 'cover_url',
					'columnName' => 'field' 
				),
				'cell_field1' => array(
					'model' => 'cell_field',
					'items' => array( 
						'simple_grid_field21' 
					),
					'field' => 'cover_url',
					'columnName' => 'field' 
				),
				'headcell_field2' => array(
					'model' => 'headcell_field',
					'items' => array( 
						'simple_grid_field22',
						'text3',
						'simple_grid_field24' 
					),
					'persistent' => false,
					'field' => 'sku',
					'columnName' => 'field' 
				),
				'cell_field2' => array(
					'model' => 'cell_field',
					'items' => array( 
						'simple_grid_field',
						'simple_grid_field2' 
					),
					'field' => 'sku',
					'columnName' => 'field' 
				),
				'headcell_field3' => array(
					'model' => 'headcell_field',
					'items' => array( 
						'simple_grid_field25' 
					),
					'persistent' => false,
					'field' => 'brand_id',
					'columnName' => 'field' 
				),
				'cell_field3' => array(
					'model' => 'cell_field',
					'items' => array( 
						'simple_grid_field3' 
					),
					'field' => 'brand_id',
					'columnName' => 'field' 
				),
				'headcell_field4' => array(
					'model' => 'headcell_field',
					'items' => array( 
						'simple_grid_field26' 
					),
					'persistent' => false,
					'field' => 'supplier_id',
					'columnName' => 'field' 
				),
				'cell_field4' => array(
					'model' => 'cell_field',
					'items' => array( 
						'simple_grid_field4' 
					),
					'field' => 'supplier_id',
					'columnName' => 'field' 
				),
				'headcell_field5' => array(
					'model' => 'headcell_field',
					'items' => array( 
						'simple_grid_field27',
						'text2',
						'simple_grid_field31',
						'text1',
						'grid_field_label' 
					),
					'persistent' => false,
					'field' => 'ean',
					'columnName' => 'field' 
				),
				'cell_field5' => array(
					'model' => 'cell_field',
					'items' => array( 
						'simple_grid_field5',
						'simple_grid_field9',
						'text',
						'grid_field' 
					),
					'field' => 'ean',
					'columnName' => 'field' 
				),
				'headcell_field18' => array(
					'model' => 'headcell_field',
					'items' => array( 
						'simple_grid_field40' 
					),
					'persistent' => false,
					'field' => 'total_stock',
					'columnName' => 'field' 
				),
				'cell_field18' => array(
					'model' => 'cell_field',
					'items' => array( 
						'simple_grid_field18' 
					),
					'field' => 'total_stock',
					'columnName' => 'field' 
				),
				'cell_dpreview' => array(
					'model' => 'cell_dpreview',
					'items' => array( 
						 
					) 
				),
				'headcell_checkbox' => array(
					'model' => 'headcell_checkbox',
					'items' => array( 
						'grid_checkbox_head' 
					),
					'persistent' => false 
				),
				'cell_checkbox' => array(
					'model' => 'cell_checkbox',
					'items' => array( 
						'grid_checkbox' 
					) 
				),
				'headcell_icons' => array(
					'model' => 'headcell_icons',
					'items' => array( 
						 
					),
					'persistent' => false 
				),
				'cell_icons' => array(
					'model' => 'cell_icons',
					'items' => array( 
						'grid_edit',
						'grid_inline_edit',
						'grid_view',
						'grid_inline_cancel',
						'grid_inline_save',
						'grid_delete' 
					) 
				),
				'headcell_details' => array(
					'model' => 'headcell_details',
					'items' => array( 
						 
					),
					'persistent' => false 
				),
				'cell_details' => array(
					'model' => 'cell_details',
					'items' => array( 
						'grid_alldetails_link' 
					) 
				),
				'headcell_field6' => array(
					'model' => 'headcell_field',
					'items' => array( 
						'simple_grid_field41' 
					),
					'field' => 'created_at',
					'columnName' => 'field' 
				),
				'cell_field6' => array(
					'model' => 'cell_field',
					'items' => array( 
						'simple_grid_field19' 
					),
					'field' => 'created_at',
					'columnName' => 'field' 
				),
				'footcell_field6' => array(
					'model' => 'footcell_field',
					'items' => array( 
						 
					) 
				) 
			),
			'deferredItems' => array( 
				 
			),
			'recsPerRow' => 1 
		) 
	),
	'items' => array(
		'page_size' => array(
			'type' => 'page_size' 
		),
		'breadcrumb' => array(
			'type' => 'breadcrumb' 
		),
		'logo' => array(
			'type' => 'logo' 
		),
		'menu' => array(
			'type' => 'menu' 
		),
		'simple_search' => array(
			'type' => 'simple_search' 
		),
		'pagination' => array(
			'type' => 'pagination' 
		),
		'details_found' => array(
			'type' => 'details_found' 
		),
		'search_panel' => array(
			'type' => 'search_panel',
			'items' => array( 
				'search_panel_field',
				'search_panel_field23',
				'search_panel_field22',
				'search_panel_field21',
				'search_panel_field20',
				'search_panel_field19',
				'search_panel_field18',
				'search_panel_field17',
				'search_panel_field16',
				'search_panel_field15',
				'search_panel_field14',
				'search_panel_field13',
				'search_panel_field12',
				'search_panel_field11',
				'search_panel_field10',
				'search_panel_field9',
				'search_panel_field8',
				'search_panel_field7',
				'search_panel_field6',
				'search_panel_field5',
				'search_panel_field4',
				'search_panel_field3',
				'search_panel_field2',
				'search_panel_field1' 
			),
			'_flexiblePanel' => true 
		),
		'list_options' => array(
			'type' => 'list_options',
			'items' => array( 
				'edit_selected',
				'export_selected',
				'delete_selected',
				'-3',
				'show_search_panel',
				'hide_search_panel',
				'-',
				'export',
				'-2',
				'import' 
			) 
		),
		'show_search_panel' => array(
			'type' => 'show_search_panel' 
		),
		'hide_search_panel' => array(
			'type' => 'hide_search_panel' 
		),
		'search_panel_field' => array(
			'field' => 'sku',
			'type' => 'search_panel_field' 
		),
		'search_panel_field1' => array(
			'field' => 'id_prestashop',
			'type' => 'search_panel_field' 
		),
		'search_panel_field2' => array(
			'field' => 'title',
			'type' => 'search_panel_field' 
		),
		'search_panel_field3' => array(
			'field' => 'brand_id',
			'type' => 'search_panel_field' 
		),
		'search_panel_field4' => array(
			'field' => 'supplier_id',
			'type' => 'search_panel_field' 
		),
		'search_panel_field5' => array(
			'field' => 'ean',
			'type' => 'search_panel_field' 
		),
		'search_panel_field6' => array(
			'field' => 'mpn',
			'type' => 'search_panel_field' 
		),
		'search_panel_field7' => array(
			'field' => 'tax_class',
			'type' => 'search_panel_field' 
		),
		'search_panel_field8' => array(
			'field' => 'weight_kg',
			'type' => 'search_panel_field' 
		),
		'search_panel_field9' => array(
			'field' => 'price_cost',
			'type' => 'search_panel_field' 
		),
		'search_panel_field10' => array(
			'field' => 'desc_short',
			'type' => 'search_panel_field' 
		),
		'search_panel_field11' => array(
			'field' => 'desc_long',
			'type' => 'search_panel_field' 
		),
		'search_panel_field12' => array(
			'field' => 'min_stock',
			'type' => 'search_panel_field' 
		),
		'search_panel_field13' => array(
			'field' => 'default_category_id',
			'type' => 'search_panel_field' 
		),
		'search_panel_field14' => array(
			'field' => 'category_1',
			'type' => 'search_panel_field' 
		),
		'search_panel_field15' => array(
			'field' => 'category_2',
			'type' => 'search_panel_field' 
		),
		'search_panel_field16' => array(
			'field' => 'category_3',
			'type' => 'search_panel_field' 
		),
		'search_panel_field17' => array(
			'field' => 'category_4',
			'type' => 'search_panel_field' 
		),
		'search_panel_field18' => array(
			'field' => 'total_stock',
			'type' => 'search_panel_field' 
		),
		'search_panel_field19' => array(
			'field' => 'created_at',
			'type' => 'search_panel_field' 
		),
		'search_panel_field20' => array(
			'field' => 'updated_at',
			'type' => 'search_panel_field' 
		),
		'search_panel_field21' => array(
			'field' => 'cover_url',
			'type' => 'search_panel_field' 
		),
		'username_button' => array(
			'type' => 'username_button',
			'items' => array( 
				'userinfo_link',
				'logout_link' 
			) 
		),
		'loginform_login' => array(
			'type' => 'loginform_login',
			'popup' => false 
		),
		'userinfo_link' => array(
			'type' => 'userinfo_link' 
		),
		'logout_link' => array(
			'type' => 'logout_link' 
		),
		'expand_menu_button' => array(
			'type' => 'expand_menu_button' 
		),
		'collapse_button' => array(
			'type' => 'collapse_button' 
		),
		'add' => array(
			'type' => 'add',
			'popup' => false 
		),
		'export' => array(
			'type' => 'export' 
		),
		'-' => array(
			'type' => '-' 
		),
		'export_selected' => array(
			'type' => 'export_selected' 
		),
		'-1' => array(
			'type' => '-' 
		),
		'import' => array(
			'type' => 'import' 
		),
		'-2' => array(
			'type' => '-' 
		),
		'print_panel' => array(
			'type' => 'print_panel',
			'items' => array( 
				'print_scope',
				'print_details',
				'print_records',
				'print_button' 
			) 
		),
		'print_scope' => array(
			'type' => 'print_scope' 
		),
		'print_button' => array(
			'type' => 'print_button' 
		),
		'print_records' => array(
			'type' => 'print_records' 
		),
		'delete' => array(
			'type' => 'delete',
			'icon' => array(
				'glyph' => 'trash',
				'style' => 0 
			),
			'buttonStyle' => 'danger',
			'label' => array(
				'type' => 0,
				'text' => ' Delete' 
			) 
		),
		'delete_selected' => array(
			'type' => 'delete_selected' 
		),
		'master_info' => array(
			'type' => 'master_info',
			'tables' => array(
				'4174' => 'true',
				'4263' => 'true',
				'4501' => 'true',
				'4592' => 'true' 
			) 
		),
		'print_details' => array(
			'type' => 'print_details',
			'tables' => array(
				'4202' => true,
				'4228' => true,
				'4285' => true,
				'4332' => true,
				'4393' => true,
				'4475' => true,
				'4560' => true 
			) 
		),
		'simple_grid_field' => array(
			'field' => 'sku',
			'type' => 'grid_field',
			'inlineAdd' => false,
			'inlineEdit' => false,
			'background' => 'transparent',
			'color' => '#0db702',
			'padding' => array(
				'bottom' => '5px' 
			),
			'bold' => true,
			'font-size' => '16px' 
		),
		'simple_grid_field22' => array(
			'type' => 'grid_field_label',
			'field' => 'sku',
			'clickSort' => true 
		),
		'simple_grid_field2' => array(
			'field' => 'title',
			'type' => 'grid_field',
			'inlineAdd' => false,
			'inlineEdit' => true,
			'bold' => true,
			'font-size' => '16px' 
		),
		'simple_grid_field24' => array(
			'type' => 'grid_field_label',
			'field' => 'title',
			'clickSort' => true 
		),
		'simple_grid_field3' => array(
			'field' => 'brand_id',
			'type' => 'grid_field',
			'inlineAdd' => false,
			'inlineEdit' => true 
		),
		'simple_grid_field25' => array(
			'type' => 'grid_field_label',
			'field' => 'brand_id',
			'clickSort' => true 
		),
		'simple_grid_field4' => array(
			'field' => 'supplier_id',
			'type' => 'grid_field',
			'inlineAdd' => false,
			'inlineEdit' => true 
		),
		'simple_grid_field26' => array(
			'type' => 'grid_field_label',
			'field' => 'supplier_id',
			'label' => array(
				'field' => 'supplier_id',
				'table' => 'products',
				'type' => 3 
			),
			'clickSort' => true 
		),
		'simple_grid_field5' => array(
			'field' => 'ean',
			'type' => 'grid_field',
			'inlineAdd' => false,
			'inlineEdit' => true 
		),
		'simple_grid_field27' => array(
			'type' => 'grid_field_label',
			'field' => 'ean',
			'clickSort' => true 
		),
		'simple_grid_field9' => array(
			'field' => 'price_cost',
			'type' => 'grid_field',
			'inlineAdd' => false,
			'inlineEdit' => true,
			'bold' => true,
			'font-size' => '16px' 
		),
		'simple_grid_field31' => array(
			'type' => 'grid_field_label',
			'field' => 'price_cost',
			'clickSort' => true 
		),
		'simple_grid_field18' => array(
			'field' => 'total_stock',
			'type' => 'grid_field',
			'inlineAdd' => false,
			'inlineEdit' => true,
			'font-size' => '16px',
			'bold' => true 
		),
		'simple_grid_field40' => array(
			'type' => 'grid_field_label',
			'field' => 'total_stock',
			'label' => array(
				'field' => 'total_stock',
				'table' => 'products',
				'type' => 3 
			),
			'clickSort' => true 
		),
		'simple_grid_field19' => array(
			'field' => 'created_at',
			'type' => 'grid_field',
			'inlineAdd' => false,
			'inlineEdit' => true 
		),
		'simple_grid_field41' => array(
			'type' => 'grid_field_label',
			'field' => 'created_at',
			'clickSort' => true 
		),
		'simple_grid_field21' => array(
			'field' => 'cover_url',
			'type' => 'grid_field',
			'inlineAdd' => false,
			'inlineEdit' => false,
			'group_by' => false 
		),
		'simple_grid_field43' => array(
			'type' => 'grid_field_label',
			'field' => 'cover_url',
			'clickSort' => true 
		),
		'grid_checkbox' => array(
			'type' => 'grid_checkbox' 
		),
		'grid_checkbox_head' => array(
			'type' => 'grid_checkbox_head' 
		),
		'grid_edit' => array(
			'type' => 'grid_edit',
			'icon' => array(
				'glyph' => 'pencil',
				'style' => 0 
			),
			'popup' => false 
		),
		'grid_view' => array(
			'type' => 'grid_view',
			'popup' => false 
		),
		'grid_alldetails_link' => array(
			'type' => 'grid_alldetails_link',
			'icon' => array(
				'glyph' => 'th-list',
				'style' => 0 
			) 
		),
		'filter_panel' => array(
			'type' => 'filter_panel',
			'items' => array( 
				'filter_panel_field' 
			) 
		),
		'filter_panel_field' => array(
			'field' => 'cover_url',
			'type' => 'filter_panel_field' 
		),
		'grid_inline_cancel' => array(
			'type' => 'grid_inline_cancel',
			'icon' => array(
				'glyph' => 'remove',
				'style' => 0 
			) 
		),
		'grid_inline_save' => array(
			'type' => 'grid_inline_save',
			'icon' => array(
				'glyph' => 'ok',
				'style' => 0 
			) 
		),
		'grid_delete' => array(
			'type' => 'delete',
			'icon' => array(
				'glyph' => 'trash',
				'style' => 0 
			),
			'label' => array(
				'type' => 0,
				'text' => '' 
			),
			'buttonStyle' => 'danger',
			'buttonSize' => 'xtra-small',
			'background' => 'transparent',
			'bold' => true 
		),
		'edit_selected' => array(
			'type' => 'edit_selected' 
		),
		'grid_inline_edit' => array(
			'type' => 'grid_inline_edit',
			'icon' => array(
				'glyph' => 'edit',
				'style' => 0 
			) 
		),
		'inline_save_all' => array(
			'type' => 'inline_save_all' 
		),
		'inline_cancel_all' => array(
			'type' => 'inline_cancel_all' 
		),
		'grid_field' => array(
			'field' => 'price_internal',
			'type' => 'grid_field',
			'inlineEdit' => true,
			'color' => '#01d000',
			'bold' => true,
			'inlineAdd' => false 
		),
		'grid_field_label' => array(
			'type' => 'grid_field_label',
			'field' => 'price_internal' 
		),
		'search_panel_field22' => array(
			'field' => 'price_internal',
			'type' => 'search_panel_field' 
		),
		'text' => array(
			'type' => 'text',
			'label' => array(
				'text' => '/',
				'type' => 0 
			),
			'editedByRte' => false 
		),
		'text1' => array(
			'type' => 'text',
			'label' => array(
				'text' => '/',
				'type' => 0 
			),
			'editedByRte' => false 
		),
		'text2' => array(
			'type' => 'text',
			'label' => array(
				'text' => '/',
				'type' => 0 
			),
			'editedByRte' => false 
		),
		'text3' => array(
			'type' => 'text',
			'label' => array(
				'text' => '/',
				'type' => 0 
			),
			'editedByRte' => false 
		),
		'search_panel_field23' => array(
			'field' => 'master_sku',
			'type' => 'search_panel_field' 
		),
		'text4' => array(
			'type' => 'text',
			'label' => array(
				'text' => 'Alias',
				'type' => 0 
			),
			'editedByRte' => false,
			'bold' => true,
			'padding' => array(
				'left' => '20px' 
			),
			'font-size' => '15px',
			'underline' => true 
		),
		'-3' => array(
			'type' => '-' 
		),
		'expand_button' => array(
			'type' => 'expand_button' 
		),
		'inline_add' => array(
			'type' => 'inline_add',
			'detailsOnly' => true 
		) 
	),
	'version' => 13,
	'reorderRows' => false,
	'reorderRowsField' => '',
	'addToBottom' => false,
	'imageItem' => array(
		'type' => 'page_image' 
	),
	'imageBgColor' => '#f2f2f2',
	'controlsBgColor' => 'white',
	'imagePosition' => 'right',
	'listTotals' => 1,
	'title' => array(
		 
	) 
);
		?>