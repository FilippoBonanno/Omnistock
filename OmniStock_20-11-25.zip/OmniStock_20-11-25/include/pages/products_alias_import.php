<?php
			$optionsArray = array(
	'fields' => array(
		'gridFields' => array( 
			'sku',
			'id_prestashop',
			'title',
			'brand_id',
			'supplier_id',
			'ean',
			'mpn',
			'tax_class',
			'weight_kg',
			'price_cost',
			'desc_short',
			'desc_long',
			'min_stock',
			'default_category_id',
			'category_1',
			'category_2',
			'category_3',
			'category_4',
			'total_stock',
			'created_at',
			'updated_at',
			'cover_url',
			'price_internal',
			'master_sku' 
		),
		'searchRequiredFields' => array( 
			 
		),
		'searchPanelFields' => array( 
			 
		),
		'fieldItems' => array(
			'sku' => array( 
				'import_field' 
			),
			'id_prestashop' => array( 
				'import_field1' 
			),
			'title' => array( 
				'import_field2' 
			),
			'brand_id' => array( 
				'import_field3' 
			),
			'supplier_id' => array( 
				'import_field4' 
			),
			'ean' => array( 
				'import_field5' 
			),
			'mpn' => array( 
				'import_field6' 
			),
			'tax_class' => array( 
				'import_field7' 
			),
			'weight_kg' => array( 
				'import_field8' 
			),
			'price_cost' => array( 
				'import_field9' 
			),
			'desc_short' => array( 
				'import_field10' 
			),
			'desc_long' => array( 
				'import_field11' 
			),
			'min_stock' => array( 
				'import_field12' 
			),
			'default_category_id' => array( 
				'import_field13' 
			),
			'category_1' => array( 
				'import_field14' 
			),
			'category_2' => array( 
				'import_field15' 
			),
			'category_3' => array( 
				'import_field16' 
			),
			'category_4' => array( 
				'import_field17' 
			),
			'total_stock' => array( 
				'import_field18' 
			),
			'created_at' => array( 
				'import_field19' 
			),
			'updated_at' => array( 
				'import_field20' 
			),
			'cover_url' => array( 
				'import_field21' 
			),
			'price_internal' => array( 
				'import_field22' 
			),
			'master_sku' => array( 
				'import_field23' 
			) 
		) 
	),
	'pageLinks' => array(
		'edit' => false,
		'add' => false,
		'view' => false,
		'print' => false 
	),
	'layoutHelper' => array(
		'formItems' => array(
			'formItems' => array(
				'supertop' => array( 
					 
				),
				'top' => array( 
					'import_header' 
				),
				'grid' => array( 
					'import_field',
					'import_field1',
					'import_field2',
					'import_field3',
					'import_field4',
					'import_field5',
					'import_field6',
					'import_field7',
					'import_field8',
					'import_field9',
					'import_field10',
					'import_field11',
					'import_field12',
					'import_field13',
					'import_field14',
					'import_field15',
					'import_field16',
					'import_field17',
					'import_field18',
					'import_field19',
					'import_field20',
					'import_field21',
					'import_field22',
					'import_field23' 
				) 
			),
			'formXtTags' => array(
				'supertop' => array( 
					 
				) 
			),
			'itemForms' => array(
				'import_header' => 'top',
				'import_field' => 'grid',
				'import_field1' => 'grid',
				'import_field2' => 'grid',
				'import_field3' => 'grid',
				'import_field4' => 'grid',
				'import_field5' => 'grid',
				'import_field6' => 'grid',
				'import_field7' => 'grid',
				'import_field8' => 'grid',
				'import_field9' => 'grid',
				'import_field10' => 'grid',
				'import_field11' => 'grid',
				'import_field12' => 'grid',
				'import_field13' => 'grid',
				'import_field14' => 'grid',
				'import_field15' => 'grid',
				'import_field16' => 'grid',
				'import_field17' => 'grid',
				'import_field18' => 'grid',
				'import_field19' => 'grid',
				'import_field20' => 'grid',
				'import_field21' => 'grid',
				'import_field22' => 'grid',
				'import_field23' => 'grid' 
			),
			'itemLocations' => array(
				 
			),
			'itemVisiblity' => array(
				 
			) 
		),
		'itemsByType' => array(
			'import_header' => array( 
				'import_header' 
			),
			'import_field' => array( 
				'import_field',
				'import_field1',
				'import_field2',
				'import_field3',
				'import_field4',
				'import_field5',
				'import_field6',
				'import_field7',
				'import_field8',
				'import_field9',
				'import_field10',
				'import_field11',
				'import_field12',
				'import_field13',
				'import_field14',
				'import_field15',
				'import_field16',
				'import_field17',
				'import_field18',
				'import_field19',
				'import_field20',
				'import_field21',
				'import_field22',
				'import_field23' 
			) 
		),
		'cellMaps' => array(
			 
		) 
	),
	'loginForm' => array(
		'loginForm' => 3 
	),
	'page' => array(
		'verticalBar' => false,
		'labeledButtons' => array(
			'update_records' => array(
				 
			),
			'print_pages' => array(
				 
			),
			'register_activate_message' => array(
				 
			),
			'details_found' => array(
				 
			) 
		),
		'hasCustomButtons' => false,
		'customButtons' => array( 
			 
		),
		'codeSnippets' => array( 
			 
		),
		'clickHandlerSnippets' => array( 
			 
		),
		'hasNotifications' => false,
		'menus' => array( 
			 
		),
		'calcTotalsFor' => 1,
		'hasCharts' => false 
	),
	'events' => array(
		'maps' => array( 
			 
		),
		'mapsData' => array(
			 
		),
		'buttons' => array( 
			 
		) 
	) 
);
			$pageArray = array(
	'id' => 'import',
	'type' => 'import',
	'layoutId' => 'first',
	'disabled' => false,
	'default' => 0,
	'forms' => array(
		'supertop' => array(
			'modelId' => 'panel-top',
			'grid' => array( 
				array(
					'cells' => array( 
						array(
							'cell' => 'c1' 
						) 
					),
					'section' => '' 
				) 
			),
			'cells' => array(
				'c1' => array(
					'model' => 'c1',
					'items' => array( 
						 
					) 
				) 
			),
			'deferredItems' => array( 
				 
			),
			'recsPerRow' => 1 
		),
		'top' => array(
			'modelId' => 'import-header',
			'grid' => array( 
				array(
					'cells' => array( 
						array(
							'cell' => 'c1' 
						) 
					),
					'section' => '' 
				) 
			),
			'cells' => array(
				'c1' => array(
					'model' => 'c1',
					'items' => array( 
						'import_header' 
					) 
				) 
			),
			'deferredItems' => array( 
				 
			),
			'recsPerRow' => 1 
		),
		'grid' => array(
			'modelId' => 'import-grid',
			'grid' => array( 
				array(
					'cells' => array( 
						array(
							'cell' => 'c1' 
						) 
					),
					'section' => '' 
				) 
			),
			'cells' => array(
				'c1' => array(
					'model' => 'c1',
					'items' => array( 
						'import_field',
						'import_field1',
						'import_field2',
						'import_field3',
						'import_field4',
						'import_field5',
						'import_field6',
						'import_field7',
						'import_field8',
						'import_field9',
						'import_field10',
						'import_field11',
						'import_field12',
						'import_field13',
						'import_field14',
						'import_field15',
						'import_field16',
						'import_field17',
						'import_field18',
						'import_field19',
						'import_field20',
						'import_field21',
						'import_field22',
						'import_field23' 
					) 
				) 
			),
			'deferredItems' => array( 
				 
			),
			'recsPerRow' => 1 
		) 
	),
	'items' => array(
		'import_header' => array(
			'type' => 'import_header' 
		),
		'import_field' => array(
			'field' => 'sku',
			'type' => 'import_field' 
		),
		'import_field1' => array(
			'field' => 'id_prestashop',
			'type' => 'import_field' 
		),
		'import_field2' => array(
			'field' => 'title',
			'type' => 'import_field' 
		),
		'import_field3' => array(
			'field' => 'brand_id',
			'type' => 'import_field' 
		),
		'import_field4' => array(
			'field' => 'supplier_id',
			'type' => 'import_field' 
		),
		'import_field5' => array(
			'field' => 'ean',
			'type' => 'import_field' 
		),
		'import_field6' => array(
			'field' => 'mpn',
			'type' => 'import_field' 
		),
		'import_field7' => array(
			'field' => 'tax_class',
			'type' => 'import_field' 
		),
		'import_field8' => array(
			'field' => 'weight_kg',
			'type' => 'import_field' 
		),
		'import_field9' => array(
			'field' => 'price_cost',
			'type' => 'import_field' 
		),
		'import_field10' => array(
			'field' => 'desc_short',
			'type' => 'import_field' 
		),
		'import_field11' => array(
			'field' => 'desc_long',
			'type' => 'import_field' 
		),
		'import_field12' => array(
			'field' => 'min_stock',
			'type' => 'import_field' 
		),
		'import_field13' => array(
			'field' => 'default_category_id',
			'type' => 'import_field' 
		),
		'import_field14' => array(
			'field' => 'category_1',
			'type' => 'import_field' 
		),
		'import_field15' => array(
			'field' => 'category_2',
			'type' => 'import_field' 
		),
		'import_field16' => array(
			'field' => 'category_3',
			'type' => 'import_field' 
		),
		'import_field17' => array(
			'field' => 'category_4',
			'type' => 'import_field' 
		),
		'import_field18' => array(
			'field' => 'total_stock',
			'type' => 'import_field' 
		),
		'import_field19' => array(
			'field' => 'created_at',
			'type' => 'import_field' 
		),
		'import_field20' => array(
			'field' => 'updated_at',
			'type' => 'import_field' 
		),
		'import_field21' => array(
			'field' => 'cover_url',
			'type' => 'import_field' 
		),
		'import_field22' => array(
			'field' => 'price_internal',
			'type' => 'import_field' 
		),
		'import_field23' => array(
			'field' => 'master_sku',
			'type' => 'import_field' 
		) 
	),
	'version' => 13,
	'imageItem' => array(
		'type' => 'page_image' 
	),
	'imageBgColor' => '#f2f2f2',
	'controlsBgColor' => 'white',
	'imagePosition' => 'right',
	'listTotals' => 1,
	'title' => array(
		 
	) 
);
		?>