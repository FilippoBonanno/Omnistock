<?php
/**
 * Crea un prodotto su PrestaShop via Webservice (POST /api/products).
 * Ora gestisce anche il caricamento dell'immagine locale (field cover_url di PHPRunner).
 */

if (!defined("RUNNER_INCLUDED")) {
    $root = dirname(__DIR__);
    require_once $root . '/include/dbcommon.php';
    require_once $root . '/connections/ConnectionManager.php';
}

/**
 * Crea un nuovo prodotto e, se presente, carica la cover image.
 */
function create_product($shop_name, array $payload)
{
    // 1) Recupera API key e URL dal DB
    $mgr = new ConnectionManager();
    $conn = $mgr->byTable("sync_settings");
    $rs = $conn->query("SELECT api_url, api_key FROM sync_settings WHERE shop_name='" . db_prepare_string($shop_name) . "' LIMIT 1");
    $cfg = $rs ? $rs->fetchAssoc() : null;
    if (!$cfg) return ["success"=>false, "http_code"=>0, "message"=>"Missing sync_settings for shop '$shop_name'"];

    $apiBase = rtrim($cfg["api_url"], '/'); // es: https://shop.example.com/api
    $apiKey  = $cfg["api_key"];

    // 2) Valida i dati minimi
    $ref  = trim((string)($payload["sku"] ?? ""));
    $name = trim((string)($payload["title"] ?? ""));
    $price = (float)($payload["price_cost"] ?? 0);
    $idCat = (int)($payload["default_category_id"] ?? 0);
    $langId = (int)($payload["lang_id"] ?? 6);
    if ($ref === "" || $name === "" || $idCat <= 0)
        return ["success"=>false,"http_code"=>0,"message"=>"Missing required fields (sku, title, default_category_id)"];

    // 3) Costruisci XML per POST /api/products
    $xml = new SimpleXMLElement('<?xml version="1.0" encoding="UTF-8"?><prestashop/>');
    $xml->addAttribute('xmlns:xlink', 'http://www.w3.org/1999/xlink');
    $product = $xml->addChild('product');
    $product->addChild('reference', htmlspecialchars($ref));
    $product->addChild('price', number_format($price, 6, '.', ''));
    $product->addChild('ean13', htmlspecialchars((string)($payload["ean"] ?? "")));
    $product->addChild('mpn', htmlspecialchars((string)($payload["mpn"] ?? "")));
    $product->addChild('weight', number_format((float)($payload["weight_kg"] ?? 0), 6, '.', ''));
    $product->addChild('id_category_default', $idCat);
    $product->addChild('active', 1);

    // Nome (multilingua)
    $nameNode = $product->addChild('name');
    $langNode = $nameNode->addChild('language', htmlspecialchars($name));
    $langNode->addAttribute('id', $langId);

    // Descrizioni
    $shortDesc = (string)($payload["desc_short"] ?? "");
    $longDesc  = (string)($payload["desc_long"] ?? "");

    $sd = $product->addChild('description_short');
    $sdLang = $sd->addChild('language', htmlspecialchars($shortDesc));
    $sdLang->addAttribute('id', $langId);

    $ld = $product->addChild('description');
    $ldLang = $ld->addChild('language', htmlspecialchars($longDesc));
    $ldLang->addAttribute('id', $langId);

    // Categoria
    $assoc = $product->addChild('associations');
    $cats = $assoc->addChild('categories');
    $cat = $cats->addChild('category');
    $cat->addChild('id', $idCat);

    // 4) Chiamata POST a PrestaShop
    $endpoint = $apiBase . '/products';
    $res = ps_call($endpoint, $apiKey, 'POST', $xml->asXML());

    // 5) Se prodotto creato e c'è immagine, carica il file
    if (!empty($res["success"]) && !empty($res["remote_product_id"])) {
        $remoteId = $res["remote_product_id"];
        $coverPath = $payload["cover_url"] ?? "";

        // PHPRunner salva il path relativo tipo "uploads/filename.jpg"
        if ($coverPath && file_exists(__DIR__ . '/../' . $coverPath)) {
            $localFile = realpath(__DIR__ . '/../' . $coverPath);
            $uploadUrl = $apiBase . '/images/products/' . $remoteId;
            $imgRes = ps_upload_image($uploadUrl, $apiKey, $localFile);
            $res["image_upload"] = $imgRes;
        }
    }

    return $res;
}

/**
 * Upload binario immagine su /api/images/products/{id}
 */
function ps_upload_image($url, $apiKey, $localFile)
{
    $ch = curl_init();
    $file = curl_file_create($localFile, mime_content_type($localFile), basename($localFile));

    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_USERPWD => $apiKey . ':',
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_POSTFIELDS => ['image' => $file],
    ]);

    $resp = curl_exec($ch);
    $http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = curl_error($ch);
    curl_close($ch);

    if ($resp === false) return ["success"=>false, "message"=>"cURL error: $err"];
    if ($http >= 200 && $http < 300) return ["success"=>true, "http_code"=>$http, "message"=>"Image uploaded"];
    return ["success"=>false, "http_code"=>$http, "message"=>"HTTP $http: ".$resp];
}

/**
 * Helper HTTP XML per chiamate /api/products
 */
function ps_call($url, $apiKey, $method, $bodyXml = null)
{
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_USERPWD => $apiKey . ':',
        CURLOPT_HTTPHEADER => ['Content-Type: application/xml', 'Accept: application/xml'],
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_TIMEOUT => 30
    ]);
    if ($bodyXml) curl_setopt($ch, CURLOPT_POSTFIELDS, $bodyXml);

    $resp = curl_exec($ch);
    $http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = curl_error($ch);
    curl_close($ch);

    if ($resp === false) return ["success"=>false,"http_code"=>0,"message"=>"cURL error: ".$err];

    if ($http >= 200 && $http < 300) {
        $remoteId = null;
        try {
            $xml = simplexml_load_string($resp);
            if ($xml && isset($xml->product->id)) $remoteId = (string)$xml->product->id;
        } catch (Throwable $e) { }
        return ["success"=>true,"http_code"=>$http,"message"=>"OK","remote_product_id"=>$remoteId];
    }

    return ["success"=>false,"http_code"=>$http,"message"=>"HTTP $http: ".$resp];
}

/**
 * Esecuzione diretta via HTTP o CLI
 */
if (php_sapi_name() !== 'cli' && basename(__FILE__) === basename($_SERVER['SCRIPT_FILENAME'])) {
    $input = $_POST;
    if (empty($input)) {
        $raw = file_get_contents('php://input');
        $json = json_decode($raw, true);
        if (is_array($json)) $input = $json;
    }

    $shop = $input["shop_name"] ?? "MainShop";
    $res = create_product($shop, $input);
    header('Content-Type: application/json');
    echo json_encode($res);
}
