<?php
error_reporting(E_ALL);
set_time_limit(0);
ini_set('display_errors', 1);

require_once __DIR__ . '/../include/dbcommon.php';
require_once __DIR__ . '/../connections/ConnectionManager.php';

$mgr = new ConnectionManager();
$conn = $mgr->byTable("sync_settings");

// Recupera dati shop
$rs = $conn->query("SELECT * FROM sync_settings WHERE shop_name='MainShop' LIMIT 1");
$shop = $rs ? $rs->fetchAssoc() : null;

if (!$shop) {
    die("❌ Nessuna configurazione trovata per MainShop.");
}

$api_url = rtrim($shop["api_url"], '/');
$api_key = $shop["api_key"];
$now = date("Y-m-d H:i:s");

// ---------------------------------------------------------------------------
// 1️⃣ Recupera tutti i prodotti
// ---------------------------------------------------------------------------
$url_products = $api_url . "/products?output_format=JSON&display=[id,name,reference,price]&ws_key=" . $api_key;

$ch = curl_init($url_products);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_SSL_VERIFYHOST => false,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_CONNECTTIMEOUT => 20,
    CURLOPT_TIMEOUT => 60,
    CURLOPT_USERAGENT => 'OmniStockBot/1.0',
    CURLOPT_HTTPHEADER => ['Accept: application/json']
]);

$response = curl_exec($ch);
$curlError = curl_error($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($response === false || trim($response) === '') {
    die("❌ Nessuna risposta dall'API prodotti. Errore: " . ($curlError ?: 'vuoto') . " (HTTP $httpCode)");
}
if ($httpCode >= 400) {
    die("❌ Errore HTTP $httpCode ricevuto dal server per i prodotti.");
}

// Decodifica JSON prodotti
$response = trim(preg_replace('/^\xEF\xBB\xBF/', '', $response));
$data = json_decode($response, true);
if (json_last_error() !== JSON_ERROR_NONE) {
    die("⚠️ Errore JSON prodotti: " . json_last_error_msg());
}

if (empty($data['products'])) {
    die("⚠️ Nessun prodotto trovato nel JSON.");
}

$products = $data['products'];

// ---------------------------------------------------------------------------
// 2️⃣ Recupera tutte le quantità stock_availables in una sola chiamata
// ---------------------------------------------------------------------------
$url_stock_all = $api_url . "/stock_availables?output_format=JSON&display=[id_product,quantity]&filter[id_shop]=1&ws_key=" . $api_key;
$ch_stock = curl_init($url_stock_all);
curl_setopt_array($ch_stock, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_SSL_VERIFYHOST => false,
    CURLOPT_CONNECTTIMEOUT => 20,
    CURLOPT_TIMEOUT => 60,
]);
$resp_stock = curl_exec($ch_stock);
curl_close($ch_stock);

$stock_all = json_decode($resp_stock, true);
$stock_map = [];
if (isset($stock_all['stock_availables']) && is_array($stock_all['stock_availables'])) {
    foreach ($stock_all['stock_availables'] as $s) {
        $stock_map[(int)$s['id_product']] = (int)$s['quantity'];
    }
}

// ---------------------------------------------------------------------------
// 3️⃣ Importa / aggiorna prodotti
// ---------------------------------------------------------------------------
echo "<h3>✅ Prodotti importati da {$shop['shop_name']}:</h3>";
$count = 0;

foreach ($products as $p) {
    $id_prestashop = (int)$p["id"];
    $sku = trim($p["reference"]);
    if ($sku == '') continue;

    $title = substr($p["name"], 0, 255);
    $price = (float)$p["price"];
    $quantity = isset($stock_map[$id_prestashop]) ? $stock_map[$id_prestashop] : 0;

    // URL immagine (proxy interno)
    $coverUrl = "http://localhost/omnistock/api/get_image.php?id=" . $id_prestashop;

    // Controlla se esiste già
    $checkSql = "SELECT COUNT(*) AS c FROM products WHERE sku=" . $conn->prepareString($sku);
    $exists = $conn->query($checkSql)->fetchAssoc();

    if ($exists["c"] > 0) {
        // Aggiorna
        $sql = sprintf(
            "UPDATE products 
             SET id_prestashop=%d, title=%s, price_cost=%.4f, total_stock=%d, updated_at=%s 
             WHERE sku=%s",
            $id_prestashop,
            $conn->prepareString($title),
            $price,
            $quantity,
            $conn->prepareString($now),
            $conn->prepareString($sku)
        );
    } else {
        // Inserisci
        $sql = sprintf(
            "INSERT INTO products (id_prestashop, sku, title, price_cost, total_stock, created_at, updated_at)
             VALUES (%d, %s, %s, %.4f, %d, %s, %s)",
            $id_prestashop,
            $conn->prepareString($sku),
            $conn->prepareString($title),
            $price,
            $quantity,
            $conn->prepareString($now),
            $conn->prepareString($now)
        );
    }
    $conn->exec($sql);

    // Aggiorna o inserisci immagine cover
    $imgSelect = sprintf(
        "SELECT id FROM product_images WHERE sku=%s AND position=0 LIMIT 1",
        $conn->prepareString($sku)
    );
    $imgRow = $conn->query($imgSelect)->fetchAssoc();

    if ($imgRow && !empty($imgRow['id'])) {
        $imgUpdate = sprintf(
            "UPDATE product_images 
             SET url=%s, is_cover=1, updated_at=%s 
             WHERE id=%s",
            $conn->prepareString($coverUrl),
            $conn->prepareString($now),
            (int)$imgRow['id']
        );
        $conn->exec($imgUpdate);
    } else {
        $imgInsert = sprintf(
            "INSERT INTO product_images (sku, position, url, is_cover, created_at, updated_at)
             VALUES (%s, 0, %s, 1, %s, %s)",
            $conn->prepareString($sku),
            $conn->prepareString($coverUrl),
            $conn->prepareString($now),
            $conn->prepareString($now)
        );
        $conn->exec($imgInsert);
    }

    $count++;
}

// ---------------------------------------------------------------------------
// 4️⃣ Aggiorna data ultima sincronizzazione
// ---------------------------------------------------------------------------
$conn->exec("UPDATE sync_settings 
             SET last_sync=" . $conn->prepareString($now) . " 
             WHERE shop_name=" . $conn->prepareString('MainShop'));

echo "<p>Totale prodotti aggiornati o inseriti: <strong>$count</strong></p>";
echo "<p>Import completato alle: " . date("H:i:s") . "</p>";
?>
