<?php
error_reporting(0);
ini_set('display_errors', 0);

if (empty($_GET['id'])) {
    http_response_code(400);
    exit('Missing id');
}

require_once __DIR__ . '/../include/dbcommon.php';
require_once __DIR__ . '/../connections/ConnectionManager.php';

$mgr = new ConnectionManager();
$conn = $mgr->byTable("sync_settings");
$rs = $conn->query("SELECT api_url, api_key FROM sync_settings WHERE shop_name='MainShop' LIMIT 1");
$shop = $rs ? $rs->fetchAssoc() : null;

if (!$shop) {
    http_response_code(500);
    exit('Shop not found');
}

$api_url = rtrim($shop['api_url'], '/');
$api_key = $shop['api_key'];
$product_id = intval($_GET['id']);

// 1️⃣ Recupera lista immagini
$image_list_url = "$api_url/images/products/$product_id";
$ch = curl_init($image_list_url);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_USERPWD => $api_key . ':',
    CURLOPT_SSL_VERIFYPEER => false, // ⚠️ Metti a true in produzione
    CURLOPT_HTTPHEADER => ['Accept: application/xml'],
]);
$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($http_code !== 200 || empty($response)) {
    http_response_code($http_code);
    exit("⚠️ Impossibile recuperare le immagini per il prodotto #$product_id");
}

// 2️⃣ Estrai declination ID dall'XML
$image_id = null;
if (preg_match('/<declination id="(\d+)"/', $response, $matches)) {
    $image_id = $matches[1];
}

if (!$image_id) {
    http_response_code(404);
    exit("⚠️ Nessuna immagine disponibile per il prodotto #$product_id");
}

// 3️⃣ Recupera immagine effettiva
$image_url = "$api_url/images/products/$product_id/$image_id";
$ch = curl_init($image_url);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_USERPWD => $api_key . ':',
    CURLOPT_SSL_VERIFYPEER => false, // ⚠️ Metti a true in produzione
    CURLOPT_HEADER => true,
]);
$data = curl_exec($ch);
$info = curl_getinfo($ch);
curl_close($ch);

if ($info['http_code'] == 200 && strpos($info['content_type'], 'image') !== false) {
    $header_size = $info['header_size'];
    $body = substr($data, $header_size);
    header('Content-Type: ' . $info['content_type']);
    echo $body;
    exit;
}

// 4️⃣ Errore finale
http_response_code($info['http_code'] ?? 500);
exit("⚠️ Immagine non disponibile per il prodotto #$product_id");
