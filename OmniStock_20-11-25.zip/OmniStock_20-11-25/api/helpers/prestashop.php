<?php
// /api/helpers/prestashop.php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../../include/dbcommon.php';
require_once __DIR__ . '/../../connections/ConnectionManager.php';

function ps_get_shop_conf($shopName = 'MainShop') {
    $mgr = new ConnectionManager();
    $conn = $mgr->byTable("sync_settings");
    $rs = $conn->query("SELECT api_url, api_key FROM sync_settings WHERE shop_name='".db_prepare_string($shopName)."' LIMIT 1");
    $row = $rs ? $rs->fetchAssoc() : null;
    if (!$row) throw new Exception("sync_settings non trovato per shop_name=$shopName");
    $row['api_url'] = rtrim($row['api_url'], '/');
    return $row;
}

function ps_request($method, $url, $apiKey, $xmlBody = null, $accept = 'application/xml') {
    $ch = curl_init($url);
    $headers = ["Accept: $accept"];
    if ($xmlBody !== null) $headers[] = "Content-Type: application/xml; charset=utf-8";

    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_USERPWD => $apiKey . ':',
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_TIMEOUT => 60
    ]);
    if ($xmlBody !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, $xmlBody);

    $response = curl_exec($ch);
    $http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    if ($response === false) {
        $err = curl_error($ch);
        curl_close($ch);
        throw new Exception("cURL error: $err");
    }
    curl_close($ch);

    if ($http < 200 || $http >= 300) {
        throw new Exception("HTTP $http: $response");
    }
    return $response;
}

/**
 * Trova id_product su PrestaShop dato reference (SKU).
 * Ritorna int id_product o null se non trovato.
 */
function ps_get_product_id_by_reference($apiUrl, $apiKey, $reference) {
    $url = $apiUrl . "/products/?filter[reference]=[" . rawurlencode($reference) . "]&display=[id,reference]";
    $xml = ps_request('GET', $url, $apiKey);
    $sx = @simplexml_load_string($xml);
    if (!$sx) return null;

    // risposta /prestashop/products/product
    if (isset($sx->products->product)) {
        foreach ($sx->products->product as $p) {
            if ((string)$p->reference === $reference || (string)$p->reference === '') {
                // Alcune versioni non ritornano reference qui, ci basta il primo match
                return (int)$p->id;
            }
        }
        // fallback: prende il primo id
        $first = $sx->products->product[0] ?? null;
        return $first ? (int)$first->id : null;
    }
    return null;
}

/**
 * Crea un prodotto minimo su PrestaShop (name ITA, reference, price, attivo).
 * Ritorna l’id_product creato.
 */
function ps_create_product_min($apiUrl, $apiKey, $data) {
    // Campi minimi: name, link_rewrite, reference, price, active
    $name = $data['title'] ?? $data['sku'];
    $reference = $data['sku'];
    $price = isset($data['price']) ? (string)$data['price'] : (isset($data['price_cost']) ? (string)$data['price_cost'] : "0");
    $active = isset($data['active']) ? (int)$data['active'] : 1;

    $linkRewrite = preg_replace('~[^a-z0-9]+~i', '-', strtolower($name));
    $linkRewrite = trim($linkRewrite, '-') ?: strtolower($reference);

    // XML secondo webservice PS
    $xml = new SimpleXMLElement('<prestashop/>');
    $product = $xml->addChild('product');

    // campi base
    $product->addChild('active', $active);
    $product->addChild('price', $price);
    $product->addChild('reference', htmlspecialchars($reference, ENT_XML1|ENT_COMPAT, 'UTF-8'));

    // name (lingue) – id=1 di solito IT, adatta se serve
    $nameNode = $product->addChild('name');
    $nameItem = $nameNode->addChild('language', htmlspecialchars($name, ENT_XML1|ENT_COMPAT, 'UTF-8'));
    $nameItem->addAttribute('id', 1);

    // link_rewrite (lingue)
    $lrNode = $product->addChild('link_rewrite');
    $lrItem = $lrNode->addChild('language', htmlspecialchars($linkRewrite, ENT_XML1|ENT_COMPAT, 'UTF-8'));
    $lrItem->addAttribute('id', 1);

    // PUT/POST: per creazione usare POST su /api/products
    $xmlBody = $xml->asXML();
    $resp = ps_request('POST', $apiUrl . '/products', $apiKey, $xmlBody);
    $sx = simplexml_load_string($resp);
    if (!$sx || !isset($sx->product->id)) {
        throw new Exception("Creazione prodotto: risposta inattesa: $resp");
    }
    return (int)$sx->product->id;
}

/**
 * Aggiorna un prodotto: carica l’XML completo da PS, sostituisce i campi base e re-invia via PUT.
 * $data può contenere title, price, active.
 */
function ps_update_product_min($apiUrl, $apiKey, $idProduct, $data) {
    $get = ps_request('GET', $apiUrl . '/products/' . (int)$idProduct, $apiKey);
    $sx = simplexml_load_string($get);
    if (!$sx || !isset($sx->product)) throw new Exception("Prodotto $idProduct non trovato su PS");

    // Modifiche minime
    if (isset($data['price'])) {
        $sx->product->price = (string)$data['price'];
    } elseif (isset($data['price_cost'])) {
        $sx->product->price = (string)$data['price_cost'];
    }
    if (isset($data['active'])) {
        $sx->product->active = (int)$data['active'];
    }
    if (isset($data['title'])) {
        // name e link_rewrite lingua id=1
        if (!isset($sx->product->name)) $sx->product->addChild('name');
        $found = false;
        foreach ($sx->product->name->language as $lng) {
            if ((string)$lng['id'] == '1') {
                $lng[0] = htmlspecialchars($data['title'], ENT_XML1|ENT_COMPAT, 'UTF-8');
                $found = true;
                break;
            }
        }
        if (!$found) {
            $ln = $sx->product->name->addChild('language', htmlspecialchars($data['title'], ENT_XML1|ENT_COMPAT, 'UTF-8'));
            $ln->addAttribute('id', 1);
        }

        $slug = preg_replace('~[^a-z0-9]+~i', '-', strtolower($data['title']));
        $slug = trim($slug, '-') ?: strtolower((string)$sx->product->reference);

        if (!isset($sx->product->link_rewrite)) $sx->product->addChild('link_rewrite');
        $found = false;
        foreach ($sx->product->link_rewrite->language as $lng) {
            if ((string)$lng['id'] == '1') {
                $lng[0] = htmlspecialchars($slug, ENT_XML1|ENT_COMPAT, 'UTF-8');
                $found = true;
                break;
            }
        }
        if (!$found) {
            $ln = $sx->product->link_rewrite->addChild('language', htmlspecialchars($slug, ENT_XML1|ENT_COMPAT, 'UTF-8'));
            $ln->addAttribute('id', 1);
        }
    }

    // PUT
    $body = $sx->asXML();
    ps_request('PUT', $apiUrl . '/products/' . (int)$idProduct, $apiKey, $body);
    return true;
}

function ps_delete_product($apiUrl, $apiKey, $idProduct) {
    ps_request('DELETE', $apiUrl . '/products/' . (int)$idProduct, $apiKey, null);
    return true;
}
