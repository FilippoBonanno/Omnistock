<?php
/**
 * Elimina un prodotto da PrestaShop (DELETE /api/products/{id})
 */

if (!defined("RUNNER_INCLUDED")) {
    $root = dirname(__DIR__);
    require_once $root . '/include/dbcommon.php';
    require_once $root . '/connections/ConnectionManager.php';
}

function delete_product($shop_name, array $payload)
{
    $mgr = new ConnectionManager();
    $conn = $mgr->byTable("sync_settings");
    $rs = $conn->query("SELECT api_url, api_key FROM sync_settings WHERE shop_name='" . db_prepare_string($shop_name) . "' LIMIT 1");
    $cfg = $rs ? $rs->fetchAssoc() : null;
    if (!$cfg) return ["success"=>false, "message"=>"Missing sync_settings for shop '$shop_name'"];

    $apiBase = rtrim($cfg["api_url"], '/');
    $apiKey  = $cfg["api_key"];

    $ref = trim((string)($payload["sku"] ?? ""));
    if ($ref === "") return ["success"=>false, "message"=>"Missing sku/reference"];

    $remoteId = $payload["remote_product_id"] ?? null;
    if (!$remoteId) {
        $remoteId = ps_find_product_id_by_reference($apiBase, $apiKey, $ref);
        if (!$remoteId) return ["success"=>false, "message"=>"Product not found on PrestaShop for '$ref'"];
    }

    $url = $apiBase . '/products/' . urlencode($remoteId);
    $res = ps_call($url, $apiKey, 'DELETE');
    $res["remote_product_id"] = $remoteId;
    return $res;
}

function ps_find_product_id_by_reference($apiBase, $apiKey, $reference)
{
    $url = $apiBase . '/products?filter[reference]=' . urlencode($reference) . '&display=[id,reference]';
    $r = ps_call($url, $apiKey, 'GET');
    if (empty($r['success'])) return null;
    try {
        $xml = @simplexml_load_string($r['_raw']);
        if ($xml && isset($xml->products->product)) {
            $p = $xml->products->product[0];
            return (string)$p->id;
        }
    } catch (Throwable $e) {}
    return null;
}

function ps_call($url, $apiKey, $method, $bodyXml = null)
{
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_USERPWD => $apiKey . ':',
        CURLOPT_HTTPHEADER => ['Accept: application/xml'],
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_TIMEOUT => 30
    ]);
    if ($bodyXml) curl_setopt($ch, CURLOPT_POSTFIELDS, $bodyXml);

    $resp = curl_exec($ch);
    $http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = curl_error($ch);
    curl_close($ch);

    $out = ["_raw"=>$resp];
    if ($resp === false) return ["success"=>false,"http_code"=>0,"message"=>"cURL error: ".$err];
    $out["success"] = ($http >= 200 && $http < 300);
    $out["http_code"] = $http;
    $out["message"] = $out["success"] ? "OK" : "HTTP $http: ".$resp;
    return $out;
}

if (php_sapi_name() !== 'cli' && basename(__FILE__) === basename($_SERVER['SCRIPT_FILENAME'])) {
    $input = $_POST ?: json_decode(file_get_contents('php://input'), true);
    $shop = $input['shop_name'] ?? 'MainShop';
    $res = delete_product($shop, $input);
    header('Content-Type: application/json');
    echo json_encode($res);
}
