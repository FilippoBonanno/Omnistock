<?php
/**
 * Aggiorna un prodotto su PrestaShop (PUT /api/products/{id}).
 * Ora gestisce anche l’upload di un’eventuale nuova immagine di copertina (cover_url).
 */

if (!defined("RUNNER_INCLUDED")) {
    $root = dirname(__DIR__);
    require_once $root . '/include/dbcommon.php';
    require_once $root . '/connections/ConnectionManager.php';
}

function update_product($shop_name, array $payload)
{
    // 1. Recupera configurazione API
    $mgr = new ConnectionManager();
    $conn = $mgr->byTable("sync_settings");
    $rs = $conn->query("SELECT api_url, api_key FROM sync_settings WHERE shop_name='" . db_prepare_string($shop_name) . "' LIMIT 1");
    $cfg = $rs ? $rs->fetchAssoc() : null;

    if (!$cfg) return ["success"=>false, "http_code"=>0, "message"=>"Missing sync_settings for shop '$shop_name'"];

    $apiBase = rtrim($cfg["api_url"], '/');
    $apiKey  = $cfg["api_key"];

    // 2. Reference obbligatoria
    $ref = trim((string)($payload["sku"] ?? ""));
    if ($ref === "") return ["success"=>false,"http_code"=>0,"message"=>"Missing sku/reference"];

    // 3. Trova ID remoto se non fornito
    $remoteId = $payload["remote_product_id"] ?? null;
    if (!$remoteId) {
        $remoteId = ps_find_product_id_by_reference($apiBase, $apiKey, $ref);
        if (!$remoteId) return ["success"=>false,"http_code"=>404,"message"=>"Product not found on PrestaShop for reference '$ref'"];
    }

    $langId = (int)($payload["lang_id"] ?? 6);

    // 4. Ottieni XML corrente del prodotto
    $current = ps_call($apiBase . '/products/' . urlencode($remoteId), $apiKey, 'GET');
    if (empty($current['success'])) {
        return ["success"=>false, "http_code"=>$current['http_code'] ?? 0, "message"=>"GET existing failed: ".($current['message'] ?? '')];
    }

    $xmlObj = @simplexml_load_string($current['_raw']);
    if(!$xmlObj || !isset($xmlObj->product)) {
        return ["success"=>false,"http_code"=>0,"message"=>"Invalid XML from GET"];
    }
    $product = $xmlObj->product;

    // 5. Aggiorna i campi dal payload
    if (isset($payload["title"])) {
        $product->name->language[0] = htmlspecialchars((string)$payload["title"]);
        $product->name->language[0]['id'] = $langId;
    }
    if (isset($payload["price_cost"]))  $product->price = number_format((float)$payload["price_cost"], 6, '.', '');
    if (isset($payload["ean"]))  $product->ean13 = htmlspecialchars((string)$payload["ean"]);
    if (isset($payload["mpn"]))  $product->mpn = htmlspecialchars((string)$payload["mpn"]);
    if (isset($payload["weight_kg"])) $product->weight = number_format((float)$payload["weight_kg"], 6, '.', '');
    if (isset($payload["default_category_id"])) $product->id_category_default = (int)$payload["default_category_id"];
    if (isset($payload["desc_short"])) {
        $product->description_short->language[0] = htmlspecialchars((string)$payload["desc_short"]);
        $product->description_short->language[0]['id'] = $langId;
    }
    if (isset($payload["desc_long"])) {
        $product->description->language[0] = htmlspecialchars((string)$payload["desc_long"]);
        $product->description->language[0]['id'] = $langId;
    }

    // 6. Categorie (associations)
    if (isset($payload["default_category_id"])) {
        if (!isset($product->associations)) $product->addChild('associations');
        if (!isset($product->associations->categories)) $product->associations->addChild('categories');
        unset($product->associations->categories->category);
        $cat = $product->associations->categories->addChild('category');
        $cat->addChild('id', (int)$payload["default_category_id"]);
    }

    // 7. PUT /api/products/{id}
    $endpoint = $apiBase . '/products/' . urlencode($remoteId);
    $res = ps_call($endpoint, $apiKey, 'PUT', $xmlObj->asXML());
    $res["remote_product_id"] = $remoteId;

    // 8. Upload immagine se presente
    $coverPath = $payload["cover_url"] ?? "";
    if ($coverPath && file_exists(__DIR__ . '/../' . $coverPath)) {
        $localFile = realpath(__DIR__ . '/../' . $coverPath);
        $uploadUrl = $apiBase . '/images/products/' . $remoteId;
        $imgRes = ps_upload_image($uploadUrl, $apiKey, $localFile);
        $res["image_upload"] = $imgRes;
    }

    return $res;
}

/**
 * Cerca l'ID prodotto su PrestaShop partendo dal reference (SKU)
 */
function ps_find_product_id_by_reference($apiBase, $apiKey, $reference)
{
    $url = $apiBase . '/products?filter[reference]=' . urlencode($reference) . '&display=[id,reference]';
    $r = ps_call($url, $apiKey, 'GET');
    if (empty($r['success'])) return null;
    try {
        $xml = @simplexml_load_string($r['_raw']);
        if ($xml && isset($xml->products->product)) {
            $productNode = $xml->products->product[0];
            if (isset($productNode->id)) return (string)$productNode->id;
        }
    } catch (Throwable $e) {}
    return null;
}

/**
 * Esegue chiamate XML al Webservice
 */
function ps_call($url, $apiKey, $method, $bodyXml = null)
{
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_USERPWD => $apiKey . ':',
        CURLOPT_HTTPHEADER => ['Content-Type: application/xml', 'Accept: application/xml'],
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_TIMEOUT => 30
    ]);
    if ($bodyXml) curl_setopt($ch, CURLOPT_POSTFIELDS, $bodyXml);

    $resp = curl_exec($ch);
    $http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = curl_error($ch);
    curl_close($ch);

    $out = ["_raw"=>$resp];
    if ($resp === false) return ["success"=>false,"http_code"=>0,"message"=>"cURL error: ".$err];

    if ($http >= 200 && $http < 300) {
        $out["success"] = true;
        $out["http_code"] = $http;
        $out["message"] = "OK";
    } else {
        $out["success"] = false;
        $out["http_code"] = $http;
        $out["message"] = "HTTP $http: ".$resp;
    }
    return $out;
}

/**
 * Upload binario immagine (identico a create_product)
 */
function ps_upload_image($url, $apiKey, $localFile)
{
    $ch = curl_init();
    $file = curl_file_create($localFile, mime_content_type($localFile), basename($localFile));

    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_USERPWD => $apiKey . ':',
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_POSTFIELDS => ['image' => $file],
    ]);

    $resp = curl_exec($ch);
    $http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = curl_error($ch);
    curl_close($ch);

    if ($resp === false) return ["success"=>false, "message"=>"cURL error: $err"];
    if ($http >= 200 && $http < 300) return ["success"=>true, "http_code"=>$http, "message"=>"Image uploaded"];
    return ["success"=>false, "http_code"=>$http, "message"=>"HTTP $http: ".$resp];
}

/**
 * Esecuzione diretta (CLI o HTTP)
 */
if (php_sapi_name() !== 'cli' && basename(__FILE__) === basename($_SERVER['SCRIPT_FILENAME'])) {
    $input = $_POST;
    if (empty($input)) {
        $raw = file_get_contents('php://input');
        $json = json_decode($raw, true);
        if (is_array($json)) $input = $json;
    }
    $shop = $input['shop_name'] ?? 'MainShop';
    $res = update_product($shop, $input);
    header('Content-Type: application/json');
    echo json_encode($res);
}
