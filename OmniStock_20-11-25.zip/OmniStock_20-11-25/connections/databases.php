<?php
global $runnerDatabases;
$runnerDatabases = array(
	'conn' => array(
		'connId' => 'conn',
		'connName' => 'omnistock_master at localhost',
		'dbType' => 0,
		'connStringType' => 'mysql',
		'connInfo' => array( 
			'localhost',
			'root',
			'',
			'',
			'omnistock_master',
			'',
			'1' 
		) 
	) 
);

global $runnerRestConnections;
$runnerRestConnections = array(
	 
);

?>